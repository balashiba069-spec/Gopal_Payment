# GOPAL Private Bill Hub

GOPAL is a private bill-payment system for one elderly user. The goal is one simple screen: refresh current-month bills, pay one bill with one tap, or pay all payable bills with one tap.

## Correct GOPAL account list

| Provider | Count | Payment options |
|---|---:|---|
| DEWA | 3 | DEWA Building 90, DEWA Building 153, DEWA Tailoring Shop |
| Dalkia | 1 | Dalkia Building 153 |
| Empower | 1 | Empower Building 90 |
| e& | 2 | e& Shop, e& Personal |
| du | 2 | Du Building 153, Du Building 90 |

Total: 9 separate bill accounts.

The private server `.env` can hold the account references for these 9 accounts. Keep that file private and do not publish it. Release ZIP files must include `.env.example`, not `.env`.

## What is included

- Current-month bill dashboard.
- Separate one-tap payment button for every account.
- Pay Total button for all payable monthly bills.
- Payment history.
- Provider receipt status tracking.
- WhatsApp receipt delivery through WhatsApp Cloud API.
- Uploaded MP3 voice prompts wired into payment states.
- Original Dalkia Building 153 payment history record for AED 1,972.50.
- Android WebView client source for the approved OTP consent flow.
- Production deploy files for `gopal.reefalhana.com`.
- Production setup status at `GET /api/setup-status`, showing exact missing live bill, payment, and receipt connections.

## Important payment rule

GOPAL must not store a raw debit card number, CVV, bank login password, or OTP. Provider portal credentials may be stored only in the private server `.env` with root-only file permissions. For real one-tap payments, enroll the payment method once through an official provider, gateway token, direct debit mandate, standing instruction, Autopay, or bank-approved payment API.

OTP cannot be bypassed or secretly read. If ADCB, the card issuer, or the provider requires OTP/3DS, GOPAL must let that official security step happen.

The approved OTP path in this package is:

```text
Live bill detected -> correct property/account -> PAY -> official provider checkout -> ADCB sends OTP -> Android asks permission -> user taps Allow -> code autofills -> user taps Confirm -> payment verified -> PAID -> receipt stored -> WhatsApp receipt sent
```

The Android client uses SMS User Consent API only. It does not ask for `READ_SMS` or `RECEIVE_SMS`, and the server never stores OTP digits.

## Voice file placement

| State | MP3 file |
|---|---|
| Welcome | `public/audio/welcome_gopal.mp3` |
| Processing | `public/audio/payment_processing.mp3` |
| Success | `public/audio/payment_success.mp3` |
| Done | `public/audio/payment_done.mp3` |
| Failed | `public/audio/payment_failed.mp3` |
| Try again | `public/audio/try_again.mp3` |
| Pending | `public/audio/payment_pending.mp3` |
| Receipt ready | `public/audio/receipt_ready.mp3` |
| Contact support | `public/audio/contact_support.mp3` |
| Thank you | `public/audio/thank_you.mp3` |

## Required live setup values

Put real values only in `.env` on the private server. Do not send debit card number, CVV, OTP, or bank password in chat.

```bash
PORT=8080
APP_BASE_URL=https://gopal.reefalhana.com
GOPAL_ANDROID_WEB_URL=https://gopal.reefalhana.com
GOPAL_OWNER_WHATSAPP_E164=+971500000000
GOPAL_PAYMENT_TOKEN_ID=token_or_mandate_from_official_enrollment

WHATSAPP_CLOUD_TOKEN=
WHATSAPP_PHONE_NUMBER_ID=
WHATSAPP_RECEIPT_TEMPLATE=

BANK_PAYMENT_API_URL=
BANK_PAYMENT_API_TOKEN=
```

GOPAL is not in demo mode. If a live bill amount is not shown, it means the official bill source has not been connected yet. The app intentionally refuses to invent an amount or mark a bill payable without provider data.

Every account needs its own account reference and at least one live bill/payment route. When the provider has a login portal, GOPAL also supports private portal fields:

```bash
*_PORTAL_URL=
*_PORTAL_USERNAME=
*_PORTAL_MOBILE=
*_PORTAL_EMAIL=
*_PORTAL_PASSWORD=
*_PORTAL_TOKEN=
```

The app displays only that a portal login is saved; it never exposes the portal password in the UI.

Core fields:

```bash
DEWA_BUILDING_90_ACCOUNT_REF=
DEWA_BUILDING_90_BENEFICIARY_REF=
DEWA_BUILDING_90_BILL_API_URL=
DEWA_BUILDING_90_BILL_API_TOKEN=
DEWA_BUILDING_90_PAYMENT_URL=

DEWA_BUILDING_153_ACCOUNT_REF=
DEWA_BUILDING_153_BENEFICIARY_REF=
DEWA_BUILDING_153_BILL_API_URL=
DEWA_BUILDING_153_BILL_API_TOKEN=
DEWA_BUILDING_153_PAYMENT_URL=

DEWA_TAILORING_SHOP_ACCOUNT_REF=
DEWA_TAILORING_SHOP_BENEFICIARY_REF=
DEWA_TAILORING_SHOP_BILL_API_URL=
DEWA_TAILORING_SHOP_BILL_API_TOKEN=
DEWA_TAILORING_SHOP_PAYMENT_URL=

DALKIA_BUILDING_153_ACCOUNT_REF=
DALKIA_BUILDING_153_BENEFICIARY_REF=
DALKIA_BUILDING_153_BILL_API_URL=
DALKIA_BUILDING_153_BILL_API_TOKEN=
DALKIA_BUILDING_153_PAYMENT_URL=

EMPOWER_BUILDING_90_ACCOUNT_REF=
EMPOWER_BUILDING_90_BENEFICIARY_REF=
EMPOWER_BUILDING_90_BILL_API_URL=
EMPOWER_BUILDING_90_BILL_API_TOKEN=
EMPOWER_BUILDING_90_PAYMENT_URL=

ETISALAT_SHOP_ACCOUNT_REF=
ETISALAT_SHOP_BENEFICIARY_REF=
ETISALAT_SHOP_BILL_API_URL=
ETISALAT_SHOP_BILL_API_TOKEN=
ETISALAT_SHOP_PAYMENT_URL=

ETISALAT_PERSONAL_ACCOUNT_REF=
ETISALAT_PERSONAL_BENEFICIARY_REF=
ETISALAT_PERSONAL_BILL_API_URL=
ETISALAT_PERSONAL_BILL_API_TOKEN=
ETISALAT_PERSONAL_PAYMENT_URL=

DU_BUILDING_153_ACCOUNT_REF=
DU_BUILDING_153_BENEFICIARY_REF=
DU_BUILDING_153_BILL_API_URL=
DU_BUILDING_153_BILL_API_TOKEN=
DU_BUILDING_153_PAYMENT_URL=

DU_BUILDING_90_ACCOUNT_REF=
DU_BUILDING_90_BENEFICIARY_REF=
DU_BUILDING_90_BILL_API_URL=
DU_BUILDING_90_BILL_API_TOKEN=
DU_BUILDING_90_PAYMENT_URL=
```

## Run

```bash
npm start
```

Open:

```text
http://localhost:8080
```

## Server endpoints

- `GET /api/health`
- `GET /api/bill-hub`
- `POST /api/bills/refresh`
- `POST /api/bills/:accountId/pay`
- `POST /api/bills/pay-total`
- `GET /api/payment-history`
- `GET /api/payment-attempts/:attemptId`
- `POST /api/payment-attempts/:attemptId/events`
- `POST /api/payment-attempts/:attemptId/verify`
- `POST /api/payments/:attemptId/otp-consent-started`
- `POST /api/payments/:attemptId/otp-autofilled`
- `POST /api/receipts/:paymentId/send-whatsapp`
- `GET /api/payment-details`
- `GET /api/setup-status`

## Android OTP client

The Android source is in `android/`. Open that folder in Android Studio and set this value in `android/app/build.gradle.kts`:

```kotlin
buildConfigField("String", "GOPAL_WEB_URL", "\"https://gopal.reefalhana.com\"")
```

The Android app loads GOPAL in a WebView. When the web dashboard opens an official provider checkout, it calls:

```javascript
AndroidGopal.prepareProviderCheckout(JSON.stringify(paymentAttempt));
```

Android then starts SMS User Consent. When the ADCB OTP arrives, Android shows its system permission sheet. Only after the user taps Allow does the app parse the 4-8 digit OTP and fill the current checkout field. It does not press Confirm automatically.

## Live connector routes

Use one approved route per provider account:

- Official provider API for bill amount and provider receipt.
- Official monthly bill email parser.
- Official provider payment link.
- Provider Autopay.
- UAE direct debit or standing instruction.
- Bank-approved server-to-server bill payment API.

Provider login automation can be added only when it follows the provider terms and does not bypass MFA, OTP, or bank security.

Official route notes are stored in `data/provider-routes.json`.

Provider verification must be connected before live production use. The provider/gateway webhook or trusted connector should call `POST /api/payment-attempts/:attemptId/verify` after the official checkout confirms paid status, with `x-gopal-webhook-token` when `GOPAL_WEBHOOK_TOKEN` is set.
