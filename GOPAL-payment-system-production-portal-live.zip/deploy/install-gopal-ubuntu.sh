#!/usr/bin/env bash
set -euo pipefail

DOMAIN="gopal.reefalhana.com"
APP_DIR="/opt/gopal-payment-system"
SERVICE_USER="gopal"
ZIP_PATH="${1:-}"

if [ "$(id -u)" -ne 0 ]; then
  echo "Run with sudo: sudo bash deploy/install-gopal-ubuntu.sh /path/to/GOPAL-payment-system-final.zip"
  exit 1
fi

if [ -z "$ZIP_PATH" ] || [ ! -f "$ZIP_PATH" ]; then
  echo "Missing ZIP path."
  echo "Usage: sudo bash deploy/install-gopal-ubuntu.sh /home/ubuntu/GOPAL-payment-system-final.zip"
  exit 1
fi

echo "Installing base packages..."
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y nodejs npm nginx unzip curl certbot python3-certbot-nginx

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js installation failed."
  exit 1
fi

NODE_MAJOR="$(node -p 'Number(process.versions.node.split(".")[0])')"
if [ "$NODE_MAJOR" -lt 18 ]; then
  echo "Node.js 18 or newer is required. Current version: $(node -v)"
  echo "Install Node.js 20 LTS, then rerun this script."
  exit 1
fi

echo "Preparing app directory..."
timestamp="$(date +%Y%m%d-%H%M%S)"
backup_dir=""
if [ -d "$APP_DIR" ]; then
  backup_dir="${APP_DIR}.backup-${timestamp}"
  mv "$APP_DIR" "$backup_dir"
fi
install -d -m 0755 "$APP_DIR"
unzip -q "$ZIP_PATH" -d "$APP_DIR"

if [ -n "$backup_dir" ] && [ -f "$backup_dir/.env" ]; then
  cp "$backup_dir/.env" "$APP_DIR/.env"
elif [ ! -f "$APP_DIR/.env" ]; then
  cp "$APP_DIR/.env.example" "$APP_DIR/.env"
fi
chmod 600 "$APP_DIR/.env"

if ! id "$SERVICE_USER" >/dev/null 2>&1; then
  useradd --system --home "$APP_DIR" --shell /usr/sbin/nologin "$SERVICE_USER"
fi
chown -R "$SERVICE_USER:$SERVICE_USER" "$APP_DIR"

echo "Installing systemd service..."
cp "$APP_DIR/deploy/systemd/gopal.service" /etc/systemd/system/gopal.service
systemctl daemon-reload
systemctl enable gopal
systemctl restart gopal

echo "Installing Nginx reverse proxy..."
install -d -m 0755 /etc/nginx/sites-available /etc/nginx/sites-enabled
cp "$APP_DIR/deploy/nginx/gopal-http.conf" "/etc/nginx/sites-available/${DOMAIN}"
if [ ! -e "/etc/nginx/sites-enabled/${DOMAIN}" ]; then
  ln -s "/etc/nginx/sites-available/${DOMAIN}" "/etc/nginx/sites-enabled/${DOMAIN}"
fi
nginx -t
systemctl reload nginx

echo "Checking local GOPAL health..."
curl -fsS http://127.0.0.1:8080/api/health >/dev/null

echo "Requesting HTTPS certificate..."
if certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos --register-unsafely-without-email --redirect; then
  echo "HTTPS enabled for https://${DOMAIN}"
else
  echo "Certbot could not finish yet. HTTP is configured; rerun after DNS fully points to this server:"
  echo "sudo certbot --nginx -d ${DOMAIN}"
fi

echo "Final service status:"
systemctl --no-pager --full status gopal || true

echo "Done. GOPAL should be available at:"
echo "https://${DOMAIN}"
