#!/usr/bin/env bash
set -euo pipefail

HOST="54.80.68.241"
USER_NAME="ubuntu"
PORT="22"
ZIP_FILE="${1:-GOPAL-payment-system-final.zip}"
KEYS=("Server1.pem" "SERVER.pem")

if [ ! -f "$ZIP_FILE" ]; then
  echo "Missing $ZIP_FILE in this folder."
  exit 1
fi

working_key=""
for key in "${KEYS[@]}"; do
  if [ ! -f "$key" ]; then
    echo "Skipping missing key: $key"
    continue
  fi

  chmod 600 "$key"
  echo "Testing $key ..."
  if ssh -i "$key" -p "$PORT" \
    -o BatchMode=yes \
    -o StrictHostKeyChecking=accept-new \
    -o ConnectTimeout=12 \
    "$USER_NAME@$HOST" 'echo GOPAL_KEY_OK' 2>/dev/null | grep -q GOPAL_KEY_OK; then
    working_key="$key"
    break
  fi
done

if [ -z "$working_key" ]; then
  echo "Neither PEM logged in."
  echo "Check EC2 security group inbound SSH, server public IP, username, and the instance key pair name."
  exit 1
fi

echo "Using key: $working_key"
scp -i "$working_key" -P "$PORT" "$ZIP_FILE" "$USER_NAME@$HOST:/home/ubuntu/GOPAL-payment-system-final.zip"
ssh -i "$working_key" -p "$PORT" "$USER_NAME@$HOST" <<'REMOTE'
set -euo pipefail
sudo apt-get update
sudo apt-get install -y unzip
tmpdir="$(mktemp -d)"
unzip -q /home/ubuntu/GOPAL-payment-system-final.zip -d "$tmpdir"
sudo bash "$tmpdir/deploy/install-gopal-ubuntu.sh" /home/ubuntu/GOPAL-payment-system-final.zip
REMOTE

echo "Done. Open https://gopal.reefalhana.com"
