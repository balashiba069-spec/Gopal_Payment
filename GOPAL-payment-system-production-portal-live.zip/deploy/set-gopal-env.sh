#!/usr/bin/env bash
set -euo pipefail

ENV_FILE="${GOPAL_ENV_FILE:-/opt/gopal-payment-system/.env}"

if [ "$#" -lt 1 ]; then
  echo "Usage: sudo bash deploy/set-gopal-env.sh KEY=VALUE [KEY=VALUE ...]"
  exit 1
fi

if [ "$(id -u)" -ne 0 ]; then
  echo "Run with sudo so the private GOPAL .env can be updated."
  exit 1
fi

if [ ! -f "$ENV_FILE" ]; then
  echo "Missing $ENV_FILE"
  exit 1
fi

backup="${ENV_FILE}.backup-$(date +%Y%m%d-%H%M%S)"
cp "$ENV_FILE" "$backup"

node - "$ENV_FILE" "$@" <<'NODE'
const fs = require("fs");

const [envFile, ...pairs] = process.argv.slice(2);
const updates = new Map();

for (const pair of pairs) {
  const equalsAt = pair.indexOf("=");
  if (equalsAt <= 0) {
    throw new Error(`Invalid KEY=VALUE pair: ${pair}`);
  }
  const key = pair.slice(0, equalsAt);
  const value = pair.slice(equalsAt + 1);
  if (!/^[A-Z0-9_]+$/.test(key)) {
    throw new Error(`Invalid env key: ${key}`);
  }
  updates.set(key, value);
}

const quoteValue = (value) => {
  if (/^[A-Za-z0-9_./:+@-]*$/.test(value)) return value;
  return JSON.stringify(value);
};

const lines = fs.readFileSync(envFile, "utf8").split(/\r?\n/);
const written = new Set();
const nextLines = lines.map((line) => {
  const match = line.match(/^([A-Z0-9_]+)=/);
  if (!match || !updates.has(match[1])) return line;
  written.add(match[1]);
  return `${match[1]}=${quoteValue(updates.get(match[1]))}`;
});

for (const [key, value] of updates) {
  if (!written.has(key)) nextLines.push(`${key}=${quoteValue(value)}`);
}

fs.writeFileSync(envFile, `${nextLines.filter((line, index, all) => {
  return line !== "" || index < all.length - 1;
}).join("\n")}\n`, "utf8");
NODE

chmod 600 "$ENV_FILE"
systemctl restart gopal
echo "Updated $ENV_FILE"
echo "Backup saved at $backup"
