# GOPAL Phone Deploy Commands

Run these from Termius, Termux, or a computer that can SSH to your server.

## If you forgot which PEM is correct

Keep both `Server1.pem` and `SERVER.pem` in the same folder as `GOPAL-payment-system-production.zip`, then run:

```bash
unzip -j GOPAL-payment-system-production.zip deploy/try-both-pems-and-deploy.sh
chmod +x try-both-pems-and-deploy.sh
./try-both-pems-and-deploy.sh GOPAL-payment-system-production.zip
```

The script tests both keys, uploads with the working one, and runs the server install.

## Upload from the folder containing both files

```bash
chmod 600 Server1.pem
scp -i Server1.pem -P 22 GOPAL-payment-system-production.zip ubuntu@54.80.68.241:/home/ubuntu/GOPAL-payment-system-production.zip
```

## Install on server

```bash
ssh -i Server1.pem -p 22 ubuntu@54.80.68.241
```

Then run:

```bash
sudo apt-get update && sudo apt-get install -y unzip
unzip -q /home/ubuntu/GOPAL-payment-system-production.zip -d /tmp/gopal-install
sudo bash /tmp/gopal-install/deploy/install-gopal-ubuntu.sh /home/ubuntu/GOPAL-payment-system-production.zip
```

The installer preserves `/opt/gopal-payment-system/.env` from the previous install. Put private live connector values only in that server file.

## Check

```bash
curl -fsS https://gopal.reefalhana.com/api/health
curl -fsS https://gopal.reefalhana.com/api/setup-status
```

## Configure provider accounts

After installing the new ZIP on the server, run `set-gopal-env.sh` from the SSH session. Keep real account references and bill amounts only in `/opt/gopal-payment-system/.env` on the server.

```bash
sudo bash /opt/gopal-payment-system/deploy/set-gopal-env.sh \
  DEWA_BUILDING_90_ACCOUNT_REF=replace_with_dewa_easypay_number \
  DEWA_BUILDING_90_PREMISE_NUMBER=replace_with_premise_number \
  DEWA_BUILDING_90_BUSINESS_PARTNER=replace_with_business_partner \
  DEWA_BUILDING_90_ACCOUNT_TYPE=Residential \
  DEWA_BUILDING_153_ACCOUNT_REF=replace_with_dewa_easypay_number \
  DEWA_BUILDING_153_PREMISE_NUMBER=replace_with_premise_number \
  DEWA_BUILDING_153_BUSINESS_PARTNER=replace_with_business_partner \
  DEWA_BUILDING_153_ACCOUNT_TYPE=Residential \
  DEWA_BUILDING_153_BILL_AMOUNT=replace_with_visible_official_amount \
  DEWA_BUILDING_153_BILL_CURRENCY=AED \
  DEWA_BUILDING_153_BILL_MONTH=YYYY-MM \
  DEWA_BUILDING_153_BILL_DUE_DATE=YYYY-MM-DD \
  DEWA_BUILDING_153_BILL_INVOICE_NUMBER=replace_with_invoice_number \
  DEWA_BUILDING_153_BILL_ISSUE_DATE=YYYY-MM-DD \
  DEWA_BUILDING_153_BILL_SOURCE="Official DEWA Green Bill" \
  DEWA_TAILORING_SHOP_ACCOUNT_REF=replace_with_dewa_easypay_number \
  DEWA_TAILORING_SHOP_PREMISE_NUMBER=replace_with_premise_number \
  DEWA_TAILORING_SHOP_BUSINESS_PARTNER=replace_with_business_partner \
  DEWA_TAILORING_SHOP_ACCOUNT_TYPE=Commercial \
  DALKIA_BUILDING_153_ACCOUNT_REF=replace_with_dalkia_account \
  EMPOWER_BUILDING_90_ACCOUNT_REF=replace_with_empower_account \
  EMPOWER_BUILDING_90_ALT_ACCOUNT_REF=replace_with_previous_or_secondary_empower_account_if_any \
  EMPOWER_BUILDING_90_PORTAL_URL=https://e-services.empower.ae/ \
  EMPOWER_BUILDING_90_PORTAL_USERNAME=replace_with_empower_username \
  EMPOWER_BUILDING_90_PORTAL_PASSWORD='replace_with_empower_password' \
  ETISALAT_SHOP_ACCOUNT_REF=replace_with_etisalat_shop_number \
  ETISALAT_PERSONAL_ACCOUNT_REF=replace_with_etisalat_personal_number \
  DU_BUILDING_153_ACCOUNT_REF=replace_with_du_account \
  DU_BUILDING_90_ACCOUNT_REF=replace_with_du_account
```

Then refresh the site and open:

```bash
curl -fsS https://gopal.reefalhana.com/api/setup-status
```
