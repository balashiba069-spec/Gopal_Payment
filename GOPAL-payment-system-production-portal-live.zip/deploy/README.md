# GOPAL Production Deploy

These files are for a Linux VPS where `gopal.reefalhana.com` already points to the server IP.

## 1. Upload and unpack

Upload `GOPAL-payment-system-final.zip` to the VPS, then place the app at:

```bash
/opt/gopal-payment-system
```

Fast install command after the ZIP is uploaded to `/home/ubuntu/GOPAL-payment-system-final.zip`:

```bash
sudo apt-get update && sudo apt-get install -y unzip
unzip -q /home/ubuntu/GOPAL-payment-system-final.zip -d /tmp/gopal-install
sudo bash /tmp/gopal-install/deploy/install-gopal-ubuntu.sh /home/ubuntu/GOPAL-payment-system-final.zip
```

## 2. Install service

```bash
sudo useradd --system --home /opt/gopal-payment-system --shell /usr/sbin/nologin gopal
sudo chown -R gopal:gopal /opt/gopal-payment-system
sudo cp /opt/gopal-payment-system/deploy/systemd/gopal.service /etc/systemd/system/gopal.service
sudo systemctl daemon-reload
sudo systemctl enable --now gopal
sudo systemctl status gopal
```

## 3. Install Nginx reverse proxy

Start with HTTP:

```bash
sudo cp /opt/gopal-payment-system/deploy/nginx/gopal-http.conf /etc/nginx/sites-available/gopal.reefalhana.com
sudo ln -s /etc/nginx/sites-available/gopal.reefalhana.com /etc/nginx/sites-enabled/gopal.reefalhana.com
sudo nginx -t
sudo systemctl reload nginx
```

Then issue HTTPS:

```bash
sudo certbot --nginx -d gopal.reefalhana.com
```

If you prefer a manual SSL file, use `deploy/nginx/gopal-ssl.conf` after Certbot creates the certificates.

## 4. Check

```bash
curl -fsS https://gopal.reefalhana.com/api/health
```

Expected result contains:

```json
{
  "ok": true,
  "system": "GOPAL Private Bill Hub"
}
```

## 5. Keep private

Do not publish `.env`. It contains the private account references and live connector tokens.
