Provider receipts can be stored in this folder by the server after a payment connector returns receipt bytes or a receipt URL.
