# GOPAL Android OTP Consent Client

This Android client wraps the private GOPAL Bill Hub in a WebView and implements the approved OTP flow:

```text
PAY -> official provider checkout -> ADCB OTP -> Android consent prompt -> user taps Allow -> OTP autofills -> user taps Confirm
```

It uses Google Play Services SMS User Consent API. It does not request `READ_SMS` or `RECEIVE_SMS`, does not read unrestricted SMS messages, and does not store OTP digits.

## Configure

Open `app/build.gradle.kts` and set `GOPAL_WEB_URL` to the live private GOPAL server URL:

```kotlin
buildConfigField("String", "GOPAL_WEB_URL", "\"https://gopal.reefalhana.com\"")
```

The GOPAL server must be reachable over HTTPS from the Android phone.

## Build

Open this `android` folder in Android Studio, sync Gradle, then build the APK.

## Native bridge contract

The web app calls:

```javascript
AndroidGopal.prepareProviderCheckout(JSON.stringify(paymentAttempt));
AndroidGopal.requestOtpConsent(paymentAttemptId);
```

The Android app can call back into the WebView:

```javascript
window.GopalOtpBridge.receiveOtp(code, { source: "android_user_consent" });
```

The OTP exists only in memory long enough to fill the current checkout input. The user still taps the official provider/bank Confirm button.
