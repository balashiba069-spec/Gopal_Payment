plugins {
  id("com.android.application")
  id("org.jetbrains.kotlin.android")
}

android {
  namespace = "com.gopal.billhub"
  compileSdk = 35

  defaultConfig {
    applicationId = "com.gopal.billhub"
    minSdk = 26
    targetSdk = 35
    versionCode = 1
    versionName = "1.0"

    buildConfigField("String", "GOPAL_WEB_URL", "\"https://gopal.reefalhana.com\"")
  }

  buildFeatures {
    buildConfig = true
  }
}

dependencies {
  implementation("androidx.activity:activity-ktx:1.9.3")
  implementation("androidx.core:core-ktx:1.13.1")
  implementation("com.google.android.gms:play-services-auth-api-phone:18.1.0")
}
