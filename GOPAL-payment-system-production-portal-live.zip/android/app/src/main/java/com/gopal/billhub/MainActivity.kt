package com.gopal.billhub

import android.annotation.SuppressLint
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.google.android.gms.auth.api.phone.SmsRetriever
import com.google.android.gms.common.api.CommonStatusCodes
import com.google.android.gms.common.api.Status
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class MainActivity : ComponentActivity() {
  private lateinit var webView: WebView
  private var smsConsentReceiver: BroadcastReceiver? = null
  private var currentAttemptId: String? = null
  private var consentStartedAtMs: Long = 0L

  private val otpRegex = Regex("""(?<!\d)\d{4,8}(?!\d)""")

  private val smsConsentLauncher =
    registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
      if (result.resultCode != Activity.RESULT_OK || result.data == null) {
        postAttemptEvent("otp_consent_cancelled", note = "User did not approve OTP message access.")
        return@registerForActivityResult
      }

      val message = result.data?.getStringExtra(SmsRetriever.EXTRA_SMS_MESSAGE).orEmpty()
      val otp = otpRegex.find(message)?.value
      if (otp == null) {
        postAttemptEvent("otp_consent_cancelled", note = "Approved SMS did not contain a 4-8 digit OTP.")
        return@registerForActivityResult
      }

      postAttemptEvent("otp_consent_approved", digitCount = otp.length)
      autofillOtp(otp)
    }

  @SuppressLint("SetJavaScriptEnabled")
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)

    webView = WebView(this)
    webView.settings.javaScriptEnabled = true
    webView.settings.domStorageEnabled = true
    webView.settings.cacheMode = WebSettings.LOAD_DEFAULT
    webView.settings.safeBrowsingEnabled = true
    webView.addJavascriptInterface(GopalJavascriptBridge(), "AndroidGopal")
    webView.webViewClient =
      object : WebViewClient() {
        override fun onPageFinished(view: WebView, url: String) {
          super.onPageFinished(view, url)
          if (currentAttemptId != null && !isGopalUrl(url)) {
            startSmsUserConsent("Provider checkout page loaded.")
          }
        }
      }

    setContentView(webView)
    registerSmsConsentReceiver()
    webView.loadUrl(BuildConfig.GOPAL_WEB_URL)
  }

  override fun onDestroy() {
    smsConsentReceiver?.let { receiver ->
      runCatching { unregisterReceiver(receiver) }
    }
    smsConsentReceiver = null
    super.onDestroy()
  }

  private fun registerSmsConsentReceiver() {
    smsConsentReceiver =
      object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
          if (intent.action != SmsRetriever.SMS_RETRIEVED_ACTION) return

          val extras = intent.extras ?: return
          val status = extras.get(SmsRetriever.EXTRA_STATUS) as? Status ?: return

          when (status.statusCode) {
            CommonStatusCodes.SUCCESS -> {
              @Suppress("DEPRECATION")
              val consentIntent = extras.getParcelable<Intent>(SmsRetriever.EXTRA_CONSENT_INTENT)
              if (consentIntent != null) {
                smsConsentLauncher.launch(consentIntent)
              }
            }

            CommonStatusCodes.TIMEOUT -> {
              postAttemptEvent("otp_consent_cancelled", note = "Timed out waiting for OTP SMS.")
            }
          }
        }
      }

    ContextCompat.registerReceiver(
      this,
      smsConsentReceiver,
      IntentFilter(SmsRetriever.SMS_RETRIEVED_ACTION),
      SmsRetriever.SEND_PERMISSION,
      null,
      ContextCompat.RECEIVER_EXPORTED
    )
  }

  private fun startSmsUserConsent(reason: String) {
    val now = System.currentTimeMillis()
    if (now - consentStartedAtMs < 45_000L) return
    consentStartedAtMs = now

    SmsRetriever.getClient(this)
      .startSmsUserConsent(null)
      .addOnSuccessListener {
        postAttemptEvent("otp_consent_requested", note = reason)
        notifyWebStatus("pending", "Waiting for OTP", "Tap Allow when Android shows the ADCB OTP request.")
      }
      .addOnFailureListener {
        postAttemptEvent("otp_consent_cancelled", note = "SMS User Consent could not start.")
        notifyWebStatus("failed", "OTP helper unavailable", "Use the OTP manually on the provider checkout.")
      }
  }

  private fun autofillOtp(otp: String) {
    val quotedOtp = JSONObject.quote(otp)
    val js =
      """
      (function(code) {
        if (window.GopalOtpBridge && typeof window.GopalOtpBridge.receiveOtp === "function") {
          window.GopalOtpBridge.receiveOtp(code, { source: "android_user_consent" });
        }

        var inputs = Array.prototype.slice.call(document.querySelectorAll("input"));
        var scored = inputs
          .filter(function(input) {
            return !input.disabled && !input.readOnly && input.offsetParent !== null;
          })
          .map(function(input) {
            var text = [
              input.autocomplete,
              input.name,
              input.id,
              input.placeholder,
              input.getAttribute("aria-label")
            ].join(" ").toLowerCase();
            var score = 0;
            if (text.indexOf("one-time-code") >= 0) score += 50;
            if (text.indexOf("otp") >= 0) score += 40;
            if (text.indexOf("verification") >= 0) score += 30;
            if (text.indexOf("code") >= 0) score += 20;
            if (input.inputMode === "numeric" || input.type === "tel") score += 10;
            return { input: input, score: score };
          })
          .sort(function(a, b) { return b.score - a.score; });

        var target = scored.length ? scored[0].input : document.activeElement;
        if (target && target.tagName === "INPUT") {
          target.focus();
          target.value = code;
          target.dispatchEvent(new Event("input", { bubbles: true }));
          target.dispatchEvent(new Event("change", { bubbles: true }));
        }
      })($quotedOtp);
      """.trimIndent()

    webView.post {
      webView.evaluateJavascript(js, null)
      notifyWebStatus("pending", "OTP filled", "Tap Confirm on the official provider checkout.")
    }
    postAttemptEvent("otp_code_autofilled", digitCount = otp.length)
  }

  private fun notifyWebStatus(state: String, title: String, text: String) {
    val js =
      """
      window.dispatchEvent(new CustomEvent("gopal:otp-status", {
        detail: { state: ${JSONObject.quote(state)}, title: ${JSONObject.quote(title)}, text: ${JSONObject.quote(text)}, voiceName: "pending" }
      }));
      """.trimIndent()
    webView.post { webView.evaluateJavascript(js, null) }
  }

  private fun postAttemptEvent(type: String, digitCount: Int? = null, note: String? = null) {
    val attemptId = currentAttemptId ?: return
    Thread {
      runCatching {
        val encodedAttemptId = URLEncoder.encode(attemptId, Charsets.UTF_8.name())
        val url = URL("${gopalBaseUrl()}/api/payment-attempts/$encodedAttemptId/events")
        val body =
          JSONObject()
            .put("type", type)
            .put("source", "android_user_consent")
            .put("rawOtpStored", false)

        if (digitCount != null) body.put("digitCount", digitCount)
        if (note != null) body.put("note", note)

        val connection = (url.openConnection() as HttpURLConnection).apply {
          requestMethod = "POST"
          doOutput = true
          connectTimeout = 10_000
          readTimeout = 10_000
          setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }

        connection.outputStream.use { stream ->
          stream.write(body.toString().toByteArray(Charsets.UTF_8))
        }
        runCatching { connection.inputStream.close() }
        runCatching { connection.errorStream?.close() }
        connection.disconnect()
      }
    }.start()
  }

  private fun gopalBaseUrl(): String = BuildConfig.GOPAL_WEB_URL.trimEnd('/')

  private fun isGopalUrl(url: String): Boolean =
    runCatching { URL(url).host == URL(BuildConfig.GOPAL_WEB_URL).host }.getOrDefault(false)

  inner class GopalJavascriptBridge {
    @JavascriptInterface
    fun prepareProviderCheckout(paymentAttemptJson: String) {
      runOnUiThread {
        currentAttemptId =
          runCatching { JSONObject(paymentAttemptJson).optString("id").takeIf { it.isNotBlank() } }
            .getOrNull()
        startSmsUserConsent("Official provider checkout is opening.")
      }
    }

    @JavascriptInterface
    fun requestOtpConsent(paymentAttemptId: String) {
      runOnUiThread {
        currentAttemptId = paymentAttemptId.takeIf { it.isNotBlank() }
        startSmsUserConsent("GOPAL requested OTP consent.")
      }
    }
  }
}
