(function () {
  const STORAGE_KEY = "gopal.currentPaymentAttempt";

  function emitStatus(state, title, text, voiceName) {
    window.dispatchEvent(
      new CustomEvent("gopal:otp-status", {
        detail: { state, title, text, voiceName }
      })
    );
  }

  function currentAttempt() {
    try {
      return JSON.parse(sessionStorage.getItem(STORAGE_KEY) || "null");
    } catch {
      return null;
    }
  }

  function storeAttempt(paymentAttempt) {
    if (!paymentAttempt || !paymentAttempt.id) return null;
    sessionStorage.setItem(STORAGE_KEY, JSON.stringify(paymentAttempt));
    return paymentAttempt;
  }

  async function sendAttemptEvent(attemptId, type, details = {}) {
    if (!attemptId) return null;
    const payload = {
      ...details,
      type,
      source: details.source || "gopal_web"
    };

    delete payload.code;
    delete payload.otp;
    delete payload.oneTimePassword;
    delete payload.one_time_password;

    try {
      const response = await fetch(`/api/payment-attempts/${encodeURIComponent(attemptId)}/events`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      return await response.json();
    } catch {
      return null;
    }
  }

  function androidBridge() {
    return window.AndroidGopal || null;
  }

  async function prepareProviderCheckout(paymentAttempt) {
    const attempt = storeAttempt(paymentAttempt);
    if (!attempt) return;

    await sendAttemptEvent(attempt.id, "provider_checkout_opened", {
      accountId: attempt.accountId,
      note: "Official provider checkout is opening."
    });

    const bridge = androidBridge();
    if (bridge && typeof bridge.prepareProviderCheckout === "function") {
      bridge.prepareProviderCheckout(JSON.stringify(attempt));
      emitStatus(
        "pending",
        "OTP helper ready",
        "Android will ask permission when ADCB sends the OTP.",
        "pending"
      );
      return;
    }

    emitStatus(
      "pending",
      "Provider checkout opening",
      "Complete the official OTP step on the provider page.",
      "pending"
    );
  }

  async function requestOtpConsent(paymentAttemptId) {
    const attempt = paymentAttemptId ? { id: paymentAttemptId } : currentAttempt();
    if (!attempt?.id) return;

    await sendAttemptEvent(attempt.id, "otp_consent_requested", {
      source: "gopal_web"
    });

    const bridge = androidBridge();
    if (bridge && typeof bridge.requestOtpConsent === "function") {
      bridge.requestOtpConsent(attempt.id);
      emitStatus(
        "pending",
        "Waiting for OTP",
        "When Android asks, tap Allow so GOPAL can fill the OTP.",
        "pending"
      );
    }
  }

  async function receiveOtp(code, meta = {}) {
    const digits = String(code || "").replace(/\D/g, "");
    if (!digits) return false;

    const input = document.querySelector(
      'input[autocomplete="one-time-code"], input[name*="otp" i], input[id*="otp" i], input[type="tel"], input[inputmode="numeric"]'
    );

    if (input) {
      input.focus();
      input.value = digits;
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
    }

    const attempt = currentAttempt();
    await sendAttemptEvent(attempt?.id, "otp_code_autofilled", {
      source: meta.source || "android_user_consent",
      digitCount: digits.length,
      note: "OTP received through Android user consent. OTP digits were not stored."
    });

    emitStatus(
      "pending",
      "OTP filled",
      "Tap Confirm on the official payment page to finish.",
      "pending"
    );
    return true;
  }

  async function paymentVerified(payload = {}) {
    const attempt = currentAttempt();
    if (!attempt?.id) return null;

    const response = await fetch(`/api/payment-attempts/${encodeURIComponent(attempt.id)}/verify`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const result = await response.json();

    if (result.ok) {
      sessionStorage.removeItem(STORAGE_KEY);
      emitStatus("success", "Payment verified", "Receipt is stored and WhatsApp delivery started.", "success");
    } else {
      emitStatus("failed", "Payment not verified", result.message || "Please try again.", "failed");
    }

    return result;
  }

  window.GopalOtpBridge = {
    prepareProviderCheckout,
    requestOtpConsent,
    receiveOtp,
    paymentVerified,
    currentAttempt
  };
})();
