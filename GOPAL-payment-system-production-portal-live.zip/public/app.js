const voiceFiles = {
  welcome: "welcome_gopal.mp3",
  processing: "payment_processing.mp3",
  success: "payment_success.mp3",
  done: "payment_done.mp3",
  failed: "payment_failed.mp3",
  retry: "try_again.mp3",
  pending: "payment_pending.mp3",
  receipt: "receipt_ready.mp3",
  support: "contact_support.mp3",
  thankYou: "thank_you.mp3"
};

const els = {
  statusBox: document.getElementById("statusBox"),
  statusTitle: document.getElementById("statusTitle"),
  statusText: document.getElementById("statusText"),
  serviceName: document.getElementById("serviceName"),
  propertyName: document.getElementById("propertyName"),
  reference: document.getElementById("reference"),
  totalAmount: document.getElementById("totalAmount"),
  currentMonth: document.getElementById("currentMonth"),
  payableCount: document.getElementById("payableCount"),
  payTotalButton: document.getElementById("payTotalButton"),
  setupBadge: document.getElementById("setupBadge"),
  setupText: document.getElementById("setupText"),
  setupSteps: document.getElementById("setupSteps"),
  billList: document.getElementById("billList"),
  refreshButton: document.getElementById("refreshButton"),
  historyRefreshButton: document.getElementById("historyRefreshButton"),
  historyList: document.getElementById("historyList"),
  receiptButton: document.getElementById("receiptButton"),
  supportButton: document.getElementById("supportButton"),
  voiceToggle: document.getElementById("voiceToggle"),
  detailsDialog: document.getElementById("detailsDialog"),
  dialogTitle: document.getElementById("dialogTitle"),
  dialogDetails: document.getElementById("dialogDetails"),
  printButton: document.getElementById("printButton")
};

let billHub = null;
let voiceEnabled = true;
let lastVoice = null;

function money(amount, currency = "AED") {
  if (!Number.isFinite(Number(amount))) return "Amount not loaded";
  return `${currency} ${Number(amount).toLocaleString("en-AE", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  })}`;
}

function audioFor(name) {
  return `/audio/${voiceFiles[name]}`;
}

async function playVoice(name) {
  if (!voiceEnabled || !voiceFiles[name]) return;
  if (lastVoice) {
    lastVoice.pause();
    lastVoice.currentTime = 0;
  }

  lastVoice = new Audio(audioFor(name));
  try {
    await lastVoice.play();
  } catch {
    // Browsers can block audio until a button press.
  }
}

async function playSequence(names) {
  for (const name of names) {
    await playVoice(name);
    if (lastVoice) {
      await new Promise((resolve) => {
        lastVoice.addEventListener("ended", resolve, { once: true });
        setTimeout(resolve, 3500);
      });
    }
  }
}

function setStatus(state, title, text, voiceName) {
  els.statusBox.dataset.state = state;
  els.statusTitle.textContent = title;
  els.statusText.textContent = text;
  if (voiceName) playVoice(voiceName);
}

window.addEventListener("gopal:otp-status", (event) => {
  const detail = event.detail || {};
  setStatus(detail.state || "pending", detail.title || "OTP pending", detail.text || "", detail.voiceName);
});

function renderHub(details) {
  els.serviceName.textContent = "One person";
  els.propertyName.textContent = `${details.accounts.length} accounts`;
  els.reference.textContent = `${details.setupSummary.accountReferencesConfigured}/${details.setupSummary.accountReferencesTotal} saved`;
  els.totalAmount.textContent = details.paymentProfile.bankConnectorConfigured
    ? "Bank ready"
    : `${details.setupSummary.providerPortalLoginsConfigured || 0} portal logins`;
  els.currentMonth.textContent = details.month || "Current month";
  els.payableCount.textContent = `${details.payableSummary.count} payable bills generated this month`;
  els.payTotalButton.textContent = `Pay Total ${money(details.payableSummary.total, details.payableSummary.currencyCode)}`;
  els.payTotalButton.disabled =
    details.payableSummary.count === 0 || !details.paymentProfile.bankConnectorConfigured;

  els.billList.innerHTML = details.accounts.map(renderBillCard).join("");
  renderProductionSetup(details.productionSetup);
  renderHistory(details.paymentHistory || []);
  renderOriginalDalkiaDetails(details.originalDalkiaPayment);

  if (details.setupSummary.accountReferencesConfigured < details.setupSummary.accountReferencesTotal) {
    setStatus(
      "pending",
      "Account details needed",
      "Some bill account references are still missing.",
      "pending"
    );
  } else if (!details.paymentProfile.bankConnectorConfigured && details.setupSummary.paymentRoutesConfigured === 0) {
    setStatus(
      "pending",
      "Production setup needed",
      "Account references are saved. Live bill, payment, and receipt connections still need official setup.",
      "pending"
    );
  } else {
    setStatus("ready", "Ready", "Bill hub is connected for one-tap payment approval.", "welcome");
  }
}

function renderBillCard(account) {
  const bill = account.bill;
  const setup = account.productionSetup || { missing: [], officialRoute: null };
  const amountText = money(bill.amount, bill.currencyCode);
  const canPay = isPayableBill(bill);
  const ready = account.payment.oneTapReady;
  const portalReady = setup.readiness && setup.readiness.providerPortalLogin;
  const canUseButton = canPay && ready;
  const statusClass = bill.needsLiveRefresh ? "warning" : canPay ? "payable" : "";
  const officialRouteKnown = setup.officialRoute && setup.officialRoute.status !== "official_route_needed";
  const routeLabel = ready
    ? "payment route connected"
    : portalReady
      ? "portal login saved"
      : officialRouteKnown
      ? "official route found"
      : account.payment.autopayEligible
        ? "autopay setup needed"
        : "payment setup needed";
  const buttonText = canUseButton
    ? `Pay ${amountText}`
    : canPay
      ? "Connect payment route"
      : "Waiting for live bill";
  const missingText = setup.missing.length
    ? setup.missing.map((item) => item.item).join(", ")
    : "Ready for live payment";

  return `
    <article class="bill-card">
      <div class="bill-main">
        <h3>${escapeHtml(account.displayName)}</h3>
        <p>${escapeHtml(account.property)}</p>
        <p class="reference-line">${escapeHtml(referenceLine(account))}</p>
        <div class="bill-meta">
          <span class="pill">${escapeHtml(account.maskedAccount)}</span>
          <span class="pill ${account.accountReferenceConfigured ? "payable" : "warning"}">${account.accountReferenceConfigured ? "account saved" : "account needed"}</span>
          <span class="pill ${statusClass}">${escapeHtml(statusLabel(bill.status))}</span>
          <span class="pill">${escapeHtml(bill.billMonth || "month needed")}</span>
          <span class="pill">${escapeHtml(amountText)}</span>
          <span class="pill ${ready ? "payable" : "warning"}">${escapeHtml(routeLabel)}</span>
        </div>
        <p class="setup-needed">Needed: ${escapeHtml(missingText)}</p>
      </div>
      <button class="bill-action" type="button" data-pay-account="${escapeHtml(account.id)}" ${canUseButton ? "" : "disabled"}>
        ${escapeHtml(buttonText)}
      </button>
    </article>
  `;
}

function renderProductionSetup(setup) {
  if (!setup) return;

  const ready = setup.status === "ready_for_live_payments";
  els.setupBadge.textContent = `${setup.summary.readyAccounts}/${setup.summary.totalAccounts} ready`;
  els.setupBadge.dataset.state = ready ? "ready" : "pending";
  els.setupText.textContent = ready
    ? "All accounts have live bill, payment, and receipt routes connected."
    : "GOPAL is installed for production, but it will not show fake bills or fake payable amounts. Connect these official items to make payments live.";

  const globalItems = setup.globalMissing.length
    ? `
      <article class="setup-item setup-global">
        <strong>Global setup still needed</strong>
        ${setup.globalMissing.map((item) => `<p>${escapeHtml(item)}</p>`).join("")}
      </article>
    `
    : "";

  const accountItems = setup.accounts
    .map((account) => {
      const route = account.officialRoute || {};
      const links = [
        route.billLookup,
        ...(route.paymentRoutes || [])
      ].filter(Boolean);
      const missing = account.missing.length
        ? account.missing.map((item) => `<p>${escapeHtml(item.item)}: ${escapeHtml(item.action)}</p>`).join("")
        : `<p>Ready for live bill refresh and payment.</p>`;
      const routeLinks = links.length
        ? `<div class="setup-links">${links.map(renderRouteLink).join("")}</div>`
        : `<p>No official public route found yet.</p>`;

      return `
        <article class="setup-item">
          <strong>${escapeHtml(account.displayName)}</strong>
          ${missing}
          ${routeLinks}
        </article>
      `;
    })
    .join("");

  els.setupSteps.innerHTML = `${globalItems}${accountItems}`;
}

function referenceLine(account) {
  const refs = account.references || {};
  const pieces = [
    `Account ${refs.accountNumber || account.maskedAccount}`,
    refs.premiseNumber && refs.premiseNumber !== "Not configured"
      ? `Premise ${refs.premiseNumber}`
      : null,
    refs.businessPartner && refs.businessPartner !== "Not configured"
      ? `BP ${refs.businessPartner}`
      : null,
    refs.accountType,
    refs.alternateAccountNumber ? `Alt ${refs.alternateAccountNumber}` : null,
    refs.portalLogin
  ].filter(Boolean);

  return pieces.join(" | ");
}

function renderRouteLink(route) {
  return `
    <a href="${escapeHtml(route.url)}" target="_blank" rel="noopener noreferrer">
      ${escapeHtml(route.label)}
    </a>
  `;
}

function statusLabel(status) {
  const labels = {
    account_details_needed: "account setup needed",
    connector_needed: "live setup needed",
    needs_refresh: "refresh needed",
    official_bill_loaded: "official bill loaded",
    no_amount_due: "no amount due",
    paid: "paid",
    loaded: "bill loaded",
    payment_submitted: "payment submitted"
  };

  return labels[status] || String(status || "unknown").replaceAll("_", " ");
}

function isPayableBill(bill) {
  if (!Number.isFinite(Number(bill.amount)) || Number(bill.amount) <= 0) return false;
  return ![
    "paid",
    "refund_follow_up",
    "connection_active_account_needed",
    "account_details_needed",
    "connector_needed",
    "needs_refresh"
  ].includes(String(bill.status || "").toLowerCase());
}

function renderHistory(payments) {
  if (!payments.length) {
    els.historyList.innerHTML = `<p class="empty">No payment history yet.</p>`;
    return;
  }

  els.historyList.innerHTML = payments
    .map(
      (payment) => `
        <article class="history-item">
          <strong>${escapeHtml(payment.accountName)}</strong>
          <p>${escapeHtml(money(payment.amount, payment.currencyCode))} - ${escapeHtml(payment.status)} - ${escapeHtml(payment.billMonth || "")}</p>
          <p>Receipt: ${escapeHtml(payment.receiptStatus || "not ready")} ${payment.whatsappSentAt ? "- WhatsApp sent" : "- WhatsApp pending"}</p>
        </article>
      `
    )
    .join("");
}

function renderOriginalDalkiaDetails(original) {
  const property = original.property;
  els.dialogTitle.textContent = "Original Dalkia Details";
  els.dialogDetails.innerHTML = `
    <div class="dialog-section">
      <strong>${escapeHtml(original.serviceName)}</strong>
      <p>${escapeHtml(`${property.community}, ${property.building}, ${property.apartment}`)}</p>
      <p>Reference: ${escapeHtml(original.reference)}</p>
    </div>
    <div class="dialog-section">
      <strong>Amount</strong>
      <p>Security deposit: ${escapeHtml(money(original.amount.securityDeposit))}</p>
      <p>Administration fee: ${escapeHtml(money(original.amount.administrationFee))}</p>
      <p>Total: ${escapeHtml(money(original.amount.total))}</p>
    </div>
    <div class="dialog-section">
      <strong>Required Documents</strong>
      ${original.requiredDocuments.map((doc) => `<p>${escapeHtml(doc)}</p>`).join("")}
    </div>
    <div class="dialog-section">
      <strong>Contacts</strong>
      ${original.contacts.map((contact) => `<p>${escapeHtml(contact)}</p>`).join("")}
    </div>
  `;
}

function renderSupportDetails() {
  els.dialogTitle.textContent = "GOPAL Setup Status";
  const profile = billHub.paymentProfile;
  const otp = profile.otpUserConsentFlow;
  els.dialogDetails.innerHTML = `
    <div class="dialog-section">
      <strong>Live payment setup</strong>
      <p>Bank connector: ${profile.bankConnectorConfigured ? "Connected" : "Needed"}</p>
      <p>Provider portal logins: ${billHub.setupSummary.providerPortalLoginsConfigured || 0}/${billHub.setupSummary.accountReferencesTotal}</p>
      <p>Payment token or mandate: ${profile.tokenConfigured ? "Ready" : "Needed"}</p>
      <p>WhatsApp receipt delivery: ${profile.whatsAppDeliveryConfigured ? "Ready" : "Needed"}</p>
      <p>Fake bill data: ${billHub.productionSetup.demoMode ? "On" : "Off"}</p>
    </div>
    <div class="dialog-section">
      <strong>Approved OTP flow</strong>
      <p>${escapeHtml(otp.sequence)}</p>
      <p>Unrestricted SMS access: ${otp.unrestrictedSmsAccessAllowed ? "Allowed" : "Not allowed"}</p>
      <p>OTP storage: ${otp.rawOtpStorageAllowed ? "Allowed" : "Not allowed"}</p>
    </div>
    <div class="dialog-section">
      <strong>Configured GOPAL accounts</strong>
      ${billHub.accounts.map((account) => `<p>${escapeHtml(account.displayName)} - ${escapeHtml(statusLabel(account.bill.status))}</p>`).join("")}
    </div>
    <div class="dialog-section">
      <strong>Official provider routes</strong>
      ${billHub.productionSetup.accounts
        .map((account) => {
          const route = account.officialRoute || {};
          const links = [route.billLookup, ...(route.paymentRoutes || [])].filter(Boolean);
          return `<p>${escapeHtml(account.displayName)}: ${links.map((link) => escapeHtml(link.label)).join(", ") || "route needed"}</p>`;
        })
        .join("")}
    </div>
  `;
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

async function loadHub() {
  const response = await fetch("/api/bill-hub");
  billHub = await response.json();
  renderHub(billHub);
  handleReturnState();
}

function handleReturnState() {
  const path = window.location.pathname;
  const params = new URLSearchParams(window.location.search);
  const state = (params.get("state") || params.get("status") || "").toLowerCase();

  if (path === "/payment/cancel") {
    setStatus("cancelled", "Payment cancelled", "The payment was cancelled before completion.", "failed");
    playVoice("retry");
    return;
  }

  if (path !== "/payment/return") return;

  if (["captured", "purchased", "success", "paid"].includes(state)) {
    setStatus("success", "Payment successful", "Receipt is ready.", "success");
    playSequence(["done", "receipt", "thankYou"]);
    return;
  }

  if (["failed", "declined", "cancelled"].includes(state)) {
    setStatus("failed", "Payment failed", "Please try again or contact support.", "failed");
    playVoice("retry");
    return;
  }

  setStatus("pending", "Payment confirmation pending", "Waiting for gateway confirmation.", "pending");
}

async function refreshBills() {
  els.refreshButton.disabled = true;
  setStatus("processing", "Refreshing bills", "Checking configured provider connectors.", "processing");

  try {
    const response = await fetch("/api/bills/refresh", { method: "POST" });
    const result = await response.json();
    if (!response.ok) throw new Error(result.message || "Bill refresh failed.");

    billHub = result;
    renderHub(billHub);
    setStatus("pending", "Bills refreshed", "Live provider connectors are still needed where marked.", "pending");
  } catch (error) {
    setStatus("failed", "Refresh failed", error.message, "failed");
    playVoice("retry");
  } finally {
    els.refreshButton.disabled = false;
  }
}

async function refreshHistory() {
  const response = await fetch("/api/payment-history");
  const history = await response.json();
  renderHistory(history.payments || []);
  setStatus("pending", "History refreshed", "Payment history is up to date.", "receipt");
}

async function payAccount(accountId, button) {
  button.disabled = true;
  setStatus("processing", "Payment processing", "Creating one-tap payment instruction.", "processing");

  try {
    const response = await fetch(`/api/bills/${accountId}/pay`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ confirm: true })
    });
    const result = await response.json();

    if (!response.ok || result.ok === false) {
      throw new Error(result.message || "Payment could not be completed.");
    }

    if (result.redirectUrl) {
      if (result.paymentAttempt && window.GopalOtpBridge) {
        await window.GopalOtpBridge.prepareProviderCheckout(result.paymentAttempt);
      }
      setStatus("pending", "Opening provider payment", result.message, "pending");
      window.location.href = result.redirectUrl;
      return;
    }

    setStatus("success", "Payment successful", result.message, "success");
    playSequence(["done", "receipt", "thankYou"]);
    await loadHub();
  } catch (error) {
    setStatus("failed", "Payment failed", error.message, "failed");
    playVoice("retry");
    button.disabled = false;
  }
}

async function payTotal() {
  els.payTotalButton.disabled = true;
  setStatus("processing", "Total payment processing", "Paying all payable bills one by one.", "processing");

  try {
    const response = await fetch("/api/bills/pay-total", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ confirm: true })
    });
    const result = await response.json();

    if (!response.ok && response.status !== 207) {
      throw new Error(result.message || "Total payment failed.");
    }

    if (result.failedCount > 0) {
      setStatus(
        "failed",
        "Some payments need attention",
        `${result.paidCount} paid, ${result.failedCount} failed.`,
        "failed"
      );
      playVoice("retry");
    } else {
      setStatus("success", "All payments successful", `${result.paidCount} bills paid.`, "success");
      playSequence(["done", "receipt", "thankYou"]);
    }

    await loadHub();
  } catch (error) {
    setStatus("failed", "Total payment failed", error.message, "failed");
    playVoice("retry");
  } finally {
    els.payTotalButton.disabled = false;
  }
}

els.voiceToggle.addEventListener("click", () => {
  voiceEnabled = !voiceEnabled;
  els.voiceToggle.textContent = voiceEnabled ? "Voice On" : "Voice Off";
  if (voiceEnabled) playVoice("welcome");
});

els.refreshButton.addEventListener("click", refreshBills);
els.historyRefreshButton.addEventListener("click", refreshHistory);
els.payTotalButton.addEventListener("click", payTotal);

els.billList.addEventListener("click", (event) => {
  const button = event.target.closest("[data-pay-account]");
  if (!button) return;
  payAccount(button.dataset.payAccount, button);
});

els.receiptButton.addEventListener("click", () => {
  playVoice("receipt");
  renderOriginalDalkiaDetails(billHub.originalDalkiaPayment);
  els.detailsDialog.showModal();
});

els.supportButton.addEventListener("click", () => {
  setStatus("pending", "Support available", "GOPAL setup status is open.", "support");
  renderSupportDetails();
  els.detailsDialog.showModal();
});

els.printButton.addEventListener("click", () => {
  playSequence(["receipt", "thankYou"]);
  window.print();
});

loadHub().catch(() => {
  setStatus("failed", "System failed", "Could not load bill hub.", "failed");
});
