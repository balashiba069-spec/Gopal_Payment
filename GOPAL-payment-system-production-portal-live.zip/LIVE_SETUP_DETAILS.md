# GOPAL Live Setup Details

The 9 account references must stay in the private server `.env`. Do not put private account references inside public release ZIP documentation.

Do not send debit card number, CVV, OTP, bank password, or recovery codes in chat. Enter those only inside the official bank/provider enrollment flow.

Provider portal login details, when needed, belong only in the private server `.env` with `chmod 600`. GOPAL masks them in the UI and release ZIP files must never include the real `.env`.

| GOPAL name | Needed to fetch bill | Needed to pay | Needed for receipt |
|---|---|---|---|
| DEWA Building 90 | DEWA contract/account/premise number or official API/bill email | Autopay/direct debit/standing instruction/bank beneficiary/payment link | DEWA receipt API, receipt email, or provider receipt link |
| DEWA Building 153 | DEWA contract/account/premise number or official API/bill email | Autopay/direct debit/standing instruction/bank beneficiary/payment link | DEWA receipt API, receipt email, or provider receipt link |
| DEWA Tailoring Shop | DEWA contract/account/premise number or official API/bill email | Autopay/direct debit/standing instruction/bank beneficiary/payment link | DEWA receipt API, receipt email, or provider receipt link |
| Dalkia Building 153 | Dalkia account number or official API/bill email | Bank beneficiary/payment link/direct debit if supported | Dalkia receipt API, receipt email, or provider receipt link |
| Empower Building 90 | Empower account number or official API/bill email | Autopay/direct debit/standing instruction/bank beneficiary/payment link | Empower receipt API, receipt email, or provider receipt link |
| e& Shop | e& account/mobile number or official API/bill email | e& Autopay/payment link/bank beneficiary | e& receipt API, receipt email, or provider receipt link |
| e& Personal | e& account/mobile number or official API/bill email | e& Autopay/payment link/bank beneficiary | e& receipt API, receipt email, or provider receipt link |
| Du Building 153 | du account number or official API/bill email | du Autopay/payment link/bank beneficiary | du receipt API, receipt email, or provider receipt link |
| Du Building 90 | du account number or official API/bill email | du Autopay/payment link/bank beneficiary | du receipt API, receipt email, or provider receipt link |

## Official provider route found

These are production setup routes, not fake/demo payment endpoints.

| Provider | Official route | GOPAL production use |
|---|---|---|
| DEWA | DEWA View Bill, EasyPay, bill payment channels, bank Auto Pay | Use contract account/EasyPay number to read current bill, then pay through DEWA/DubaiNow/ADCB direct debit, Auto Pay, or approved payment link |
| du | du Quick Pay, du My Account, du app Auto-payment | Use saved du account numbers to reach the bill, then use du saved-card/auto-payment or account-specific payment route |
| e& | e& Quick Pay, e& online services, e& Autopay, Business Online Portal | Use mobile/account number to load bills, then use e& saved-card/Autopay or business portal route for the shop account |
| Empower | Empower e-Services / Pay As Guest / official app | Use Empower account to view/download bill and pay through the official portal, app, direct debit, or approved route |
| Dalkia | Dalkia Billing & Collection contact | Use Dalkia invoice/payment link/bank beneficiary/direct-debit details because no public quick-pay URL was found |

## DEWA first setup

For DEWA, set `*_ACCOUNT_REF` to the DEWA Account Number / EasyPay number from the Green Bill, not only the premise number.

| GOPAL name | `.env` account field | `.env` premise field | `.env` business partner field |
|---|---|---|---|
| DEWA Building 90 | `DEWA_BUILDING_90_ACCOUNT_REF` | `DEWA_BUILDING_90_PREMISE_NUMBER` | `DEWA_BUILDING_90_BUSINESS_PARTNER` |
| DEWA Building 153 | `DEWA_BUILDING_153_ACCOUNT_REF` | `DEWA_BUILDING_153_PREMISE_NUMBER` | `DEWA_BUILDING_153_BUSINESS_PARTNER` |
| DEWA Tailoring Shop | `DEWA_TAILORING_SHOP_ACCOUNT_REF` | `DEWA_TAILORING_SHOP_PREMISE_NUMBER` | `DEWA_TAILORING_SHOP_BUSINESS_PARTNER` |

If a real DEWA bill PDF/screenshot is available before the automated DEWA connector is ready, load it as an official snapshot with:

```bash
DEWA_BUILDING_153_BILL_AMOUNT=
DEWA_BUILDING_153_BILL_CURRENCY=AED
DEWA_BUILDING_153_BILL_MONTH=
DEWA_BUILDING_153_BILL_DUE_DATE=
DEWA_BUILDING_153_BILL_INVOICE_NUMBER=
DEWA_BUILDING_153_BILL_ISSUE_DATE=
DEWA_BUILDING_153_BILL_SOURCE="Official DEWA Green Bill"
DEWA_BUILDING_153_BILL_SOURCE_URL=
```

The snapshot shows a real provider bill amount in GOPAL, but the automatic monthly refresh remains pending until a DEWA API, bill-email parser, or approved portal integration is connected.

## Remaining provider setup

These fields are now supported for Dalkia, Empower, e&, and du. Set `*_ACCOUNT_REF` from the known account or phone number, then add official bill snapshots only when the amount is visible from a real provider bill/invoice.

If a provider gives more than one identifier for the same account, keep the active payment/login account in `*_ACCOUNT_REF` and put the older or alternate identifier in `*_ALT_ACCOUNT_REF`.

| GOPAL name | Account field | Portal login fields | Official bill snapshot fields | Payment route field |
|---|---|---|---|---|
| Dalkia Building 153 | `DALKIA_BUILDING_153_ACCOUNT_REF` | `DALKIA_BUILDING_153_PORTAL_URL`, `DALKIA_BUILDING_153_PORTAL_USERNAME`, `DALKIA_BUILDING_153_PORTAL_PASSWORD` if Dalkia gives a portal | `DALKIA_BUILDING_153_BILL_AMOUNT`, `DALKIA_BUILDING_153_BILL_MONTH`, `DALKIA_BUILDING_153_BILL_DUE_DATE`, `DALKIA_BUILDING_153_BILL_INVOICE_NUMBER`, `DALKIA_BUILDING_153_BILL_SOURCE_URL` | `DALKIA_BUILDING_153_PAYMENT_URL` or `DALKIA_BUILDING_153_BENEFICIARY_REF` |
| Empower Building 90 | `EMPOWER_BUILDING_90_ACCOUNT_REF`, optional `EMPOWER_BUILDING_90_ALT_ACCOUNT_REF` | `EMPOWER_BUILDING_90_PORTAL_URL`, `EMPOWER_BUILDING_90_PORTAL_USERNAME`, `EMPOWER_BUILDING_90_PORTAL_PASSWORD` | `EMPOWER_BUILDING_90_BILL_AMOUNT`, `EMPOWER_BUILDING_90_BILL_MONTH`, `EMPOWER_BUILDING_90_BILL_DUE_DATE`, `EMPOWER_BUILDING_90_BILL_INVOICE_NUMBER`, `EMPOWER_BUILDING_90_BILL_SOURCE_URL` | `EMPOWER_BUILDING_90_PAYMENT_URL` or `EMPOWER_BUILDING_90_BENEFICIARY_REF` |
| e& Shop | `ETISALAT_SHOP_ACCOUNT_REF` | `ETISALAT_SHOP_PORTAL_URL`, `ETISALAT_SHOP_PORTAL_USERNAME`, `ETISALAT_SHOP_PORTAL_PASSWORD` if business portal login is used | `ETISALAT_SHOP_BILL_AMOUNT`, `ETISALAT_SHOP_BILL_MONTH`, `ETISALAT_SHOP_BILL_DUE_DATE`, `ETISALAT_SHOP_BILL_INVOICE_NUMBER`, `ETISALAT_SHOP_BILL_SOURCE_URL` | `ETISALAT_SHOP_PAYMENT_URL` or `ETISALAT_SHOP_BENEFICIARY_REF` |
| e& Personal | `ETISALAT_PERSONAL_ACCOUNT_REF` | `ETISALAT_PERSONAL_PORTAL_URL`, `ETISALAT_PERSONAL_PORTAL_MOBILE`, `ETISALAT_PERSONAL_PORTAL_TOKEN` if e& gives an approved app/API token | `ETISALAT_PERSONAL_BILL_AMOUNT`, `ETISALAT_PERSONAL_BILL_MONTH`, `ETISALAT_PERSONAL_BILL_DUE_DATE`, `ETISALAT_PERSONAL_BILL_INVOICE_NUMBER`, `ETISALAT_PERSONAL_BILL_SOURCE_URL` | `ETISALAT_PERSONAL_PAYMENT_URL` or `ETISALAT_PERSONAL_BENEFICIARY_REF` |
| Du Building 153 | `DU_BUILDING_153_ACCOUNT_REF` | `DU_BUILDING_153_PORTAL_URL`, `DU_BUILDING_153_PORTAL_USERNAME`, `DU_BUILDING_153_PORTAL_PASSWORD` if My Account login is used | `DU_BUILDING_153_BILL_AMOUNT`, `DU_BUILDING_153_BILL_MONTH`, `DU_BUILDING_153_BILL_DUE_DATE`, `DU_BUILDING_153_BILL_INVOICE_NUMBER`, `DU_BUILDING_153_BILL_SOURCE_URL` | `DU_BUILDING_153_PAYMENT_URL` or `DU_BUILDING_153_BENEFICIARY_REF` |
| Du Building 90 | `DU_BUILDING_90_ACCOUNT_REF` | `DU_BUILDING_90_PORTAL_URL`, `DU_BUILDING_90_PORTAL_USERNAME`, `DU_BUILDING_90_PORTAL_PASSWORD` if My Account login is used | `DU_BUILDING_90_BILL_AMOUNT`, `DU_BUILDING_90_BILL_MONTH`, `DU_BUILDING_90_BILL_DUE_DATE`, `DU_BUILDING_90_BILL_INVOICE_NUMBER`, `DU_BUILDING_90_BILL_SOURCE_URL` | `DU_BUILDING_90_PAYMENT_URL` or `DU_BUILDING_90_BENEFICIARY_REF` |

For all providers, `_BILL_SOURCE` should be the official origin, such as `Official du bill`, `Official e& bill`, `Official Empower bill`, or `Official Dalkia invoice`.

Do not set `*_PAYMENT_URL` to a generic public quick-pay page unless it pre-fills or opens the exact account payment. GOPAL treats `*_PAYMENT_URL` as an account-specific official payment route.

## Do not put these in chat

- Debit card number.
- CVV.
- ADCB online banking password.
- OTP.
- Bank recovery questions or recovery codes.

Use the official provider/bank enrollment page or the private server `.env` for approved tokens, API keys, and non-card connector secrets.

WhatsApp receipt delivery needs:

- WhatsApp Cloud API token.
- WhatsApp phone number ID.
- Recipient number in `GOPAL_OWNER_WHATSAPP_E164`.

Approved Android OTP flow needs:

- The Android app in `android/` built with the private GOPAL HTTPS URL.
- Google Play Services on the phone.
- ADCB/provider OTP still enabled.
- Grandfather taps Android `Allow` on the SMS consent prompt.
- Grandfather taps the official provider/bank `Confirm` button after autofill.

GOPAL must not request unrestricted SMS permissions. Keep `READ_SMS` and `RECEIVE_SMS` out of the Android manifest.

One-tap payment needs one of these official routes:

- Provider Autopay.
- UAE direct debit mandate.
- Standing instruction.
- Bank-approved bill payment API.
- Provider-approved saved payment token.
- Official account-specific payment link.

Provider verification needs:

- Provider/gateway webhook, receipt API, or trusted connector.
- `POST /api/payment-attempts/:attemptId/verify` called only after the official provider confirms paid status.
- `GOPAL_WEBHOOK_TOKEN` set on the server and sent as `x-gopal-webhook-token` by the trusted connector.
