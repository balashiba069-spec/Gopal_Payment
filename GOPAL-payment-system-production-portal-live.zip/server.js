const http = require("http");
const fs = require("fs");
const fsp = require("fs/promises");
const path = require("path");
const { URL } = require("url");

const ROOT_DIR = __dirname;
const PUBLIC_DIR = path.join(ROOT_DIR, "public");
const DATA_DIR = path.join(ROOT_DIR, "data");
const PAYMENT_DETAILS_PATH = path.join(DATA_DIR, "payment-details.json");
const BILL_ACCOUNTS_PATH = path.join(DATA_DIR, "bill-accounts.json");
const PROVIDER_ROUTES_PATH = path.join(DATA_DIR, "provider-routes.json");
const BILL_CACHE_PATH = path.join(DATA_DIR, "bill-cache.json");
const PAYMENT_HISTORY_PATH = path.join(DATA_DIR, "payment-history.json");
const PAYMENT_EVENTS_PATH = path.join(DATA_DIR, "payment-events.jsonl");
const PAYMENT_ATTEMPTS_PATH = path.join(DATA_DIR, "payment-attempts.json");

loadEnv(path.join(ROOT_DIR, ".env"));

const PAYMENT_DETAILS = JSON.parse(fs.readFileSync(PAYMENT_DETAILS_PATH, "utf8"));
const BILL_ACCOUNTS = JSON.parse(fs.readFileSync(BILL_ACCOUNTS_PATH, "utf8"));
const PROVIDER_ROUTES = readJsonOrDefault(PROVIDER_ROUTES_PATH, {
  updatedAt: null,
  providers: {}
});

const VOICE_FILES = {
  welcome: "welcome_gopal.mp3",
  processing: "payment_processing.mp3",
  success: "payment_success.mp3",
  done: "payment_done.mp3",
  failed: "payment_failed.mp3",
  retry: "try_again.mp3",
  pending: "payment_pending.mp3",
  receipt: "receipt_ready.mp3",
  support: "contact_support.mp3",
  thankYou: "thank_you.mp3"
};

const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".mp3": "audio/mpeg",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".svg": "image/svg+xml"
};

function loadEnv(filePath) {
  if (!fs.existsSync(filePath)) return;

  const lines = fs.readFileSync(filePath, "utf8").split(/\r?\n/);
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const equalsAt = trimmed.indexOf("=");
    if (equalsAt === -1) continue;

    const key = trimmed.slice(0, equalsAt).trim();
    const rawValue = trimmed.slice(equalsAt + 1).trim();
    if (!key || process.env[key] !== undefined) continue;

    process.env[key] = rawValue.replace(/^["']|["']$/g, "");
  }
}

function readJsonOrDefault(filePath, fallback) {
  if (!fs.existsSync(filePath)) return fallback;
  return JSON.parse(fs.readFileSync(filePath, "utf8"));
}

function gatewayConfig() {
  const env = process.env.NGENIUS_ENV || "disabled";
  const production = env === "production";
  const baseUrl =
    process.env.NGENIUS_BASE_URL ||
    (production
      ? "https://api-gateway.ngenius-payments.com"
      : "https://api-gateway.sandbox.ngenius-payments.com");

  return {
    env,
    production,
    baseUrl,
    apiKey: process.env.NGENIUS_API_KEY,
    outletRef: process.env.NGENIUS_OUTLET_REF,
    realm: process.env.NGENIUS_REALM || (production ? "networkinternational" : "ni")
  };
}

function publicGatewayStatus() {
  const cfg = gatewayConfig();
  const enabled = Boolean(
    cfg.env !== "disabled" &&
      cfg.apiKey &&
      cfg.outletRef &&
      !cfg.apiKey.includes("replace_with") &&
      !cfg.outletRef.includes("replace_with")
  );

  return {
    enabled,
    mode: cfg.env,
    provider: "Network International N-Genius Hosted Payment Page"
  };
}

function hasValue(value) {
  return Boolean(value && !String(value).includes("replace_with"));
}

function maskedEnvValue(envName, fallbackEnding = "") {
  const value = process.env[envName];
  const ending = value ? String(value).slice(-4) : fallbackEnding;
  if (!ending) return "Not configured";
  return `Ending ${ending}`;
}

function accountReferenceConfigured(account) {
  return hasValue(process.env[account.accountRefEnv]);
}

function envPrefixForAccount(account) {
  return account.accountRefEnv.replace(/_ACCOUNT_REF$/, "");
}

function envNameForAccount(account, suffix) {
  return `${envPrefixForAccount(account)}_${suffix}`;
}

function providerRouteUrlFor(account) {
  const route = PROVIDER_ROUTES.providers[account.provider] || {};
  return route.billLookup?.url || route.paymentRoutes?.[0]?.url || null;
}

function providerPortalStatus(account) {
  const portalUrlEnv = envNameForAccount(account, "PORTAL_URL");
  const portalUsernameEnv = envNameForAccount(account, "PORTAL_USERNAME");
  const portalMobileEnv = envNameForAccount(account, "PORTAL_MOBILE");
  const portalEmailEnv = envNameForAccount(account, "PORTAL_EMAIL");
  const portalPasswordEnv = envNameForAccount(account, "PORTAL_PASSWORD");
  const portalTokenEnv = envNameForAccount(account, "PORTAL_TOKEN");
  const urlKnown = hasValue(process.env[portalUrlEnv]) || Boolean(providerRouteUrlFor(account));
  const loginConfigured =
    hasValue(process.env[portalUsernameEnv]) ||
    hasValue(process.env[portalMobileEnv]) ||
    hasValue(process.env[portalEmailEnv]);
  const secretConfigured =
    hasValue(process.env[portalPasswordEnv]) || hasValue(process.env[portalTokenEnv]);

  return {
    configured: urlKnown && loginConfigured && secretConfigured,
    urlKnown,
    loginConfigured,
    secretConfigured
  };
}

function providerPortalConfigured(account) {
  return providerPortalStatus(account).configured;
}

function billConnectorConfigured(account) {
  return (
    hasValue(process.env[account.billFetch.apiUrlEnv]) &&
    hasValue(process.env[account.billFetch.apiTokenEnv])
  );
}

function officialBillSnapshot(account) {
  const prefix = envPrefixForAccount(account);
  const rawAmount = process.env[`${prefix}_BILL_AMOUNT`];
  if (!hasValue(rawAmount)) return null;

  const amount = Number(rawAmount);
  if (!Number.isFinite(amount) || amount < 0) return null;

  const currencyCode = process.env[`${prefix}_BILL_CURRENCY`] || "AED";
  const invoiceNumber = process.env[`${prefix}_BILL_INVOICE_NUMBER`] || null;
  const billMonth = process.env[`${prefix}_BILL_MONTH`] || currentMonth();
  const source = process.env[`${prefix}_BILL_SOURCE`] || "Official provider bill snapshot";
  const description =
    process.env[`${prefix}_BILL_DESCRIPTION`] ||
    `${account.displayName} official bill${invoiceNumber ? ` invoice ${invoiceNumber}` : ""}`;

  return {
    accountId: account.id,
    status: amount > 0 ? "official_bill_loaded" : "no_amount_due",
    amount,
    currencyCode,
    dueDate: process.env[`${prefix}_BILL_DUE_DATE`] || null,
    billMonth,
    description,
    source,
    invoiceNumber,
    issueDate: process.env[`${prefix}_BILL_ISSUE_DATE`] || null,
    sourceUrl: process.env[`${prefix}_BILL_SOURCE_URL`] || null,
    receiptStatus: "not_paid",
    needsLiveRefresh: false,
    refreshedAt: new Date().toISOString()
  };
}

function effectiveBillForAccount(cache, account) {
  const existing = billForAccount(cache, account.id);
  const snapshot = officialBillSnapshot(account);
  const existingStatus = String(existing?.status || "").toLowerCase();
  const replaceableStatus = new Set([
    "",
    "account_details_needed",
    "connector_needed",
    "needs_refresh"
  ]);

  if (snapshot && (!existing || replaceableStatus.has(existingStatus))) {
    return snapshot;
  }

  return existing || snapshot;
}

function publicReferenceDetails(account) {
  const prefix = envPrefixForAccount(account);
  const alternateAccount = maskedEnvValue(`${prefix}_ALT_ACCOUNT_REF`);
  const portal = providerPortalStatus(account);

  return {
    accountNumber: maskedEnvValue(account.accountRefEnv, account.accountEnding || ""),
    alternateAccountNumber: alternateAccount !== "Not configured" ? alternateAccount : null,
    premiseNumber: maskedEnvValue(`${prefix}_PREMISE_NUMBER`),
    businessPartner: maskedEnvValue(`${prefix}_BUSINESS_PARTNER`),
    accountType: hasValue(process.env[`${prefix}_ACCOUNT_TYPE`])
      ? process.env[`${prefix}_ACCOUNT_TYPE`]
      : null,
    portalLogin: portal.configured
      ? "Provider portal login saved"
      : portal.loginConfigured || portal.secretConfigured
        ? "Provider portal login incomplete"
        : null
  };
}

function providerPaymentLinkConfigured(account) {
  return hasValue(process.env[account.payment.paymentUrlEnv]);
}

function providerRouteFor(account) {
  const route = PROVIDER_ROUTES.providers[account.provider] || {};
  return {
    provider: account.provider,
    status: route.status || "official_route_needed",
    billLookup: route.billLookup || null,
    paymentRoutes: route.paymentRoutes || [],
    productionInputNeeded: route.productionInputNeeded || []
  };
}

function productionSetupForAccount(account, bill) {
  const profile = publicPaymentProfile();
  const hasAccountReference = accountReferenceConfigured(account);
  const hasBillConnector = billConnectorConfigured(account);
  const portal = providerPortalStatus(account);
  const hasProviderPortal = portal.configured;
  const hasOfficialSnapshot = Boolean(officialBillSnapshot(account));
  const hasProviderPaymentLink = providerPaymentLinkConfigured(account);
  const hasPaymentRoute = hasProviderPaymentLink || profile.bankConnectorConfigured;
  const hasLoadedLiveBill =
    bill &&
    bill.needsLiveRefresh === false &&
    Number.isFinite(Number(bill.amount)) &&
    Number(bill.amount) >= 0;
  const missing = [];

  if (!hasAccountReference) {
    missing.push({
      item: "Account reference",
      action: `Save the real account reference in ${account.accountRefEnv}.`
    });
  }

  if (!hasBillConnector && !hasOfficialSnapshot) {
    if (hasProviderPortal) {
      missing.push({
        item: "Automated portal bill reader",
        action:
          "Provider portal login is saved. Add the private portal connector on the server so GOPAL can fetch the current official bill and receipt from that account."
      });
    } else {
      missing.push({
        item: "Live bill source",
        action: `Connect ${account.billFetch.apiUrlEnv} and ${account.billFetch.apiTokenEnv}, save provider portal credentials, or add an approved bill-email/parser connector.`
      });
    }
  } else if (!hasBillConnector && hasOfficialSnapshot) {
    missing.push({
      item: "Automated monthly bill refresh",
      action: hasProviderPortal
        ? "A real official bill snapshot is loaded and provider portal login is saved. Add the private portal connector on the server so future monthly bills refresh automatically."
        : `A real official bill snapshot is loaded. Connect ${account.billFetch.apiUrlEnv} and ${account.billFetch.apiTokenEnv}, save provider portal credentials, or add a bill-email/parser connector so future monthly bills refresh automatically.`
    });
  }

  if (!hasPaymentRoute) {
    missing.push({
      item: "One-tap payment route",
      action: hasProviderPortal
        ? `Provider portal login is saved. Enroll an approved saved-card, Autopay, direct-debit, bank beneficiary, or account-specific checkout route, then connect ${account.payment.paymentUrlEnv} or BANK_PAYMENT_API_URL/BANK_PAYMENT_API_TOKEN.`
        : `Connect ${account.payment.paymentUrlEnv}, a provider Autopay/direct-debit route, or BANK_PAYMENT_API_URL/BANK_PAYMENT_API_TOKEN.`
    });
  }

  if (!profile.whatsAppDeliveryConfigured) {
    missing.push({
      item: "WhatsApp receipt delivery",
      action: "Connect WHATSAPP_CLOUD_TOKEN and WHATSAPP_PHONE_NUMBER_ID."
    });
  }

  return {
    accountId: account.id,
    displayName: account.displayName,
    provider: account.provider,
    status: missing.length ? "production_setup_required" : "ready_for_live_payment",
    officialRoute: providerRouteFor(account),
    readiness: {
      accountReference: hasAccountReference,
      liveBillConnector: hasBillConnector,
      liveBillLoaded: hasLoadedLiveBill,
      providerPortalLogin: hasProviderPortal,
      providerPortalUrlKnown: portal.urlKnown,
      officialBillSnapshot: hasOfficialSnapshot,
      providerPaymentLink: hasProviderPaymentLink,
      bankConnector: profile.bankConnectorConfigured,
      paymentTokenOrMandate: profile.tokenConfigured,
      whatsappReceiptDelivery: profile.whatsAppDeliveryConfigured
    },
    missing
  };
}

function productionSetupPayload(accounts) {
  const setupAccounts = accounts.map((account) => account.productionSetup);
  const readyAccounts = setupAccounts.filter((account) => account.missing.length === 0).length;
  const profile = publicPaymentProfile();
  const globalMissing = [];

  if (!profile.bankConnectorConfigured && setupAccounts.every((account) => !account.readiness.providerPaymentLink)) {
    globalMissing.push(
      "Connect a bank-approved bill payment API or account-specific official provider payment links."
    );
  }

  if (!profile.tokenConfigured) {
    globalMissing.push(
      "Enroll the card, direct debit mandate, provider Autopay, or payment token once through an official channel."
    );
  }

  if (!profile.whatsAppDeliveryConfigured) {
    globalMissing.push("Connect WhatsApp Cloud API for automatic receipt delivery.");
  }

  return {
    status: readyAccounts === setupAccounts.length ? "ready_for_live_payments" : "provider_access_required",
    updatedAt: new Date().toISOString(),
    providerRoutesUpdatedAt: PROVIDER_ROUTES.updatedAt,
    demoMode: false,
    realPaymentPolicy:
      "GOPAL will not invent bill amounts, bypass OTP, or submit payments outside official provider, bank, gateway, Autopay, direct-debit, or saved-token routes.",
    summary: {
      readyAccounts,
      totalAccounts: setupAccounts.length,
      accountReferencesConfigured: setupAccounts.filter(
        (account) => account.readiness.accountReference
      ).length,
      liveBillConnectorsConfigured: setupAccounts.filter(
        (account) => account.readiness.liveBillConnector
      ).length,
      providerPortalLoginsConfigured: setupAccounts.filter(
        (account) => account.readiness.providerPortalLogin
      ).length,
      officialBillSnapshotsConfigured: setupAccounts.filter(
        (account) => account.readiness.officialBillSnapshot
      ).length,
      paymentRoutesConfigured: setupAccounts.filter(
        (account) => account.readiness.providerPaymentLink || account.readiness.bankConnector
      ).length,
      whatsAppDeliveryConfigured: profile.whatsAppDeliveryConfigured
    },
    globalMissing,
    accounts: setupAccounts
  };
}

function publicPaymentProfile() {
  const whatsappPhone = process.env[BILL_ACCOUNTS.owner.whatsappEnv];
  const whatsappToken = process.env[BILL_ACCOUNTS.whatsapp.cloudTokenEnv];
  const whatsappPhoneNumberId = process.env[BILL_ACCOUNTS.whatsapp.phoneNumberIdEnv];

  return {
    onePersonMode: true,
    rawCardStorageAllowed: false,
    otpBypassAllowed: false,
    ownerWhatsAppConfigured: hasValue(whatsappPhone),
    whatsAppDeliveryConfigured: hasValue(whatsappToken) && hasValue(whatsappPhoneNumberId),
    tokenConfigured: hasValue(process.env[BILL_ACCOUNTS.paymentProfile.defaultTokenEnv]),
    bankConnectorConfigured:
      hasValue(process.env[BILL_ACCOUNTS.paymentProfile.bankApiUrlEnv]) &&
      hasValue(process.env[BILL_ACCOUNTS.paymentProfile.bankApiTokenEnv]),
    otpUserConsentFlow: {
      enabled: true,
      unrestrictedSmsAccessAllowed: false,
      rawOtpStorageAllowed: false,
      androidBridgeName: "AndroidGopal",
      sequence:
        "PAY -> official provider checkout -> ADCB OTP -> Android consent prompt -> user taps Allow -> OTP autofills -> user confirms"
    },
    policy: BILL_ACCOUNTS.paymentProfile.policy
  };
}

function readBillCache() {
  if (!fs.existsSync(BILL_CACHE_PATH)) {
    return { updatedAt: new Date().toISOString(), month: currentMonth(), bills: [] };
  }
  return JSON.parse(fs.readFileSync(BILL_CACHE_PATH, "utf8"));
}

async function writeBillCache(cache) {
  await fsp.writeFile(BILL_CACHE_PATH, `${JSON.stringify(cache, null, 2)}\n`, "utf8");
}

function readPaymentHistory() {
  if (!fs.existsSync(PAYMENT_HISTORY_PATH)) {
    return { payments: [] };
  }
  return JSON.parse(fs.readFileSync(PAYMENT_HISTORY_PATH, "utf8"));
}

async function writePaymentHistory(history) {
  await fsp.writeFile(PAYMENT_HISTORY_PATH, `${JSON.stringify(history, null, 2)}\n`, "utf8");
}

function readPaymentAttempts() {
  if (!fs.existsSync(PAYMENT_ATTEMPTS_PATH)) {
    return { attempts: [] };
  }
  return JSON.parse(fs.readFileSync(PAYMENT_ATTEMPTS_PATH, "utf8"));
}

async function writePaymentAttempts(attempts) {
  await fsp.writeFile(PAYMENT_ATTEMPTS_PATH, `${JSON.stringify(attempts, null, 2)}\n`, "utf8");
}

function billForAccount(cache, accountId) {
  return cache.bills.find((bill) => bill.accountId === accountId) || null;
}

function publicBillAccount(account, bill) {
  const paymentProfile = publicPaymentProfile();
  const canUseProviderPaymentLink = providerPaymentLinkConfigured(account);
  const canUseBankPaymentApi = paymentProfile.bankConnectorConfigured;
  const canUseToken = paymentProfile.tokenConfigured;
  const hasAccountReference = accountReferenceConfigured(account);
  const hasProviderPortal = providerPortalConfigured(account);
  const publicBill = normalizePublicBill(account, bill, hasAccountReference, hasProviderPortal);

  return {
    id: account.id,
    provider: account.provider,
    displayName: account.displayName,
    category: account.category,
    property: account.property || account.displayName,
    maskedAccount: maskedEnvValue(account.accountRefEnv, account.accountEnding || ""),
    references: publicReferenceDetails(account),
    accountReferenceConfigured: hasAccountReference,
    bill: publicBill,
    payment: {
      strategy: account.payment.strategy,
      supportsAutopay: account.payment.supportsAutopay,
      providerPaymentLinkConfigured: canUseProviderPaymentLink,
      bankPaymentApiConfigured: canUseBankPaymentApi,
      providerPortalConfigured: hasProviderPortal,
      tokenConfigured: canUseToken,
      autopayEligible: account.payment.supportsAutopay,
      oneTapReady: canUseProviderPaymentLink || canUseBankPaymentApi
    },
    productionSetup: productionSetupForAccount(account, publicBill)
  };
}

function normalizePublicBill(account, bill, hasAccountReference, hasProviderPortal) {
  const publicBill =
    bill || {
      status: "needs_refresh",
      amount: null,
      currencyCode: "AED",
      dueDate: null,
      billMonth: currentMonth(),
      description: "No bill has been loaded yet.",
      receiptStatus: "not_paid",
      needsLiveRefresh: true
    };

  if (hasAccountReference && publicBill.status === "account_details_needed") {
    return {
      ...publicBill,
      status: "connector_needed",
      description: hasProviderPortal
        ? `${account.displayName} account reference and provider portal login are saved. Add the private portal connector on the server to fetch the live monthly bill.`
        : `${account.displayName} account reference is saved. Add a bill connector, provider portal login, or provider payment route to fetch the live monthly bill.`,
      source: "Private GOPAL runtime config"
    };
  }

  return publicBill;
}

function currentMonth() {
  return new Date().toISOString().slice(0, 7);
}

function isPayableBill(bill) {
  if (!bill || !Number.isFinite(Number(bill.amount)) || Number(bill.amount) <= 0) return false;

  const blockedStatuses = new Set([
    "paid",
    "refund_follow_up",
    "connection_active_account_needed",
    "account_details_needed",
    "connector_needed",
    "needs_refresh"
  ]);

  return !blockedStatuses.has(String(bill.status || "").toLowerCase());
}

function billHubPayload() {
  const cache = readBillCache();
  const history = readPaymentHistory();
  const accounts = BILL_ACCOUNTS.accounts.map((account) =>
    publicBillAccount(account, effectiveBillForAccount(cache, account))
  );
  const payableAccounts = accounts.filter((account) => isPayableBill(account.bill));
  const accountReferencesConfigured = accounts.filter(
    (account) => account.accountReferenceConfigured
  ).length;
  const billConnectorsConfigured = BILL_ACCOUNTS.accounts.filter((account) =>
    billConnectorConfigured(account)
  ).length;
  const providerPortalLoginsConfigured = BILL_ACCOUNTS.accounts.filter((account) =>
    providerPortalConfigured(account)
  ).length;
  const paymentRoutesConfigured = accounts.filter((account) => account.payment.oneTapReady).length;

  return {
    systemName: "GOPAL Private Bill Hub",
    owner: {
      displayName: BILL_ACCOUNTS.owner.displayName,
      mode: BILL_ACCOUNTS.owner.mode
    },
    paymentProfile: publicPaymentProfile(),
    updatedAt: cache.updatedAt,
    month: cache.month || currentMonth(),
    accountCount: accounts.length,
    setupSummary: {
      accountReferencesConfigured,
      billConnectorsConfigured,
      providerPortalLoginsConfigured,
      paymentRoutesConfigured,
      accountReferencesTotal: accounts.length
    },
    payableSummary: {
      count: payableAccounts.length,
      currencyCode: "AED",
      total: payableAccounts.reduce((sum, account) => sum + Number(account.bill.amount), 0)
    },
    productionSetup: productionSetupPayload(accounts),
    originalDalkiaPayment: PAYMENT_DETAILS,
    accounts,
    paymentHistory: history.payments.slice(0, 10),
    voices: VOICE_FILES
  };
}

async function fetchBillFromConfiguredApi(account) {
  const apiUrl = process.env[account.billFetch.apiUrlEnv];
  const apiToken = process.env[account.billFetch.apiTokenEnv];
  if (!billConnectorConfigured(account)) return null;

  const response = await fetch(apiUrl, {
    headers: {
      Authorization: `Bearer ${apiToken}`,
      Accept: "application/json"
    }
  });
  const data = await safeJson(response);
  if (!response.ok) {
    throw gatewayError(`${account.displayName} bill refresh failed.`, response.status, data);
  }

  return {
    accountId: account.id,
    status: data.status || "loaded",
    amount: data.amount ?? data.balance ?? null,
    currencyCode: data.currencyCode || "AED",
    dueDate: data.dueDate || null,
    billMonth: data.billMonth || data.month || currentMonth(),
    description: data.description || `${account.displayName} current bill`,
    source: "Configured provider bill API",
    receiptStatus: "not_paid",
    needsLiveRefresh: false,
    refreshedAt: new Date().toISOString()
  };
}

async function refreshBills() {
  const cache = readBillCache();
  const refreshedBills = [];

  for (const account of BILL_ACCOUNTS.accounts) {
    const existing = billForAccount(cache, account.id);
    const refreshed = await fetchBillFromConfiguredApi(account);
    const snapshot = officialBillSnapshot(account);
    refreshedBills.push(
      refreshed ||
        snapshot ||
        {
          ...(existing || {
            accountId: account.id,
            status: "connector_needed",
            amount: null,
            currencyCode: "AED",
            dueDate: null,
            billMonth: currentMonth(),
            description: providerPortalConfigured(account)
              ? `${account.displayName} provider portal login is saved. Add the private portal connector on the server to fetch the official bill.`
              : `${account.displayName} needs a provider API, provider portal login, bill email parser, Autopay, or payment link connector.`,
            source: "GOPAL connector configuration",
            receiptStatus: "not_paid"
          }),
          needsLiveRefresh: true
        }
    );
  }

  const nextCache = {
    updatedAt: new Date().toISOString(),
    month: currentMonth(),
    bills: refreshedBills
  };
  await writeBillCache(nextCache);
  return billHubPayload();
}

async function createOneTapPaymentInstruction(accountId, options = {}) {
  const account = BILL_ACCOUNTS.accounts.find((item) => item.id === accountId);
  if (!account) {
    const err = new Error("Bill account was not found.");
    err.statusCode = 404;
    err.code = "account_not_found";
    throw err;
  }

  const cache = readBillCache();
  const bill = effectiveBillForAccount(cache, account);
  if (!isPayableBill(bill)) {
    const err = new Error("No payable bill amount is currently loaded for this account.");
    err.statusCode = 409;
    err.code = "no_payable_bill";
    throw err;
  }

  const paymentUrl = process.env[account.payment.paymentUrlEnv];
  if (hasValue(paymentUrl)) {
    if (options.allowRedirect === false) {
      const err = new Error("This account only has a provider payment link, so it cannot be included in Pay Total.");
      err.statusCode = 424;
      err.code = "total_payment_needs_bank_connector";
      throw err;
    }

    const paymentAttempt = await createPaymentAttempt(
      account,
      bill,
      "provider_payment_link",
      paymentUrl,
      options.batchId || null
    );
    await appendPaymentEvent({
      type: "provider_payment_link_started",
      accountId,
      attemptId: paymentAttempt.id,
      amount: bill.amount,
      currencyCode: bill.currencyCode,
      createdAt: new Date().toISOString()
    });

    return {
      ok: true,
      mode: "provider_payment_link",
      redirectUrl: paymentUrl,
      paymentAttempt: publicPaymentAttempt(paymentAttempt),
      otpPolicy: otpPolicy(),
      message: "Opening official provider payment link."
    };
  }

  const paymentProfile = publicPaymentProfile();
  if (paymentProfile.bankConnectorConfigured) {
    if (!hasValue(process.env[account.accountRefEnv])) {
      const err = new Error(`${account.displayName} account reference is needed before payment.`);
      err.statusCode = 409;
      err.code = "account_reference_needed";
      throw err;
    }

    const result = await callBankPaymentApi(account, bill);
    const payment = await recordPayment(account, bill, result, {
      batchId: options.batchId || null,
      paymentAttemptId: result.paymentAttemptId || null
    });
    await appendPaymentEvent({
      type: "bank_payment_instruction_created",
      accountId,
      amount: bill.amount,
      currencyCode: bill.currencyCode,
      paymentId: payment.id,
      bankResult: result,
      createdAt: new Date().toISOString()
    });

    return {
      ok: true,
      mode: "bank_payment_api",
      message: "Bank payment instruction created.",
      payment,
      bankResult: result
    };
  }

  if (account.payment.supportsAutopay) {
    return {
      ok: false,
      code: "autopay_enrollment_needed",
      mode: "provider_autopay",
      message: "Enable this provider's official Autopay once, then GOPAL can track it from one place."
    };
  }

  const err = new Error("A safe payment connector is needed for this account.");
  err.statusCode = 424;
  err.code = "payment_connector_needed";
  throw err;
}

async function callBankPaymentApi(account, bill) {
  const url = process.env[BILL_ACCOUNTS.paymentProfile.bankApiUrlEnv];
  const token = process.env[BILL_ACCOUNTS.paymentProfile.bankApiTokenEnv];

  const response = await fetch(url, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
      Accept: "application/json"
    },
    body: JSON.stringify({
      provider: account.provider,
      accountReference: process.env[account.accountRefEnv],
      paymentTokenId: process.env[BILL_ACCOUNTS.paymentProfile.defaultTokenEnv],
      bankBeneficiaryReference: account.payment.bankBeneficiaryRefEnv
        ? process.env[account.payment.bankBeneficiaryRefEnv]
        : undefined,
      amount: bill.amount,
      currencyCode: bill.currencyCode,
      description: bill.description,
      requestedBy: "GOPAL Private Bill Hub"
    })
  });

  const data = await safeJson(response);
  if (!response.ok) {
    throw gatewayError(`${account.displayName} bank payment failed.`, response.status, data);
  }

  return data;
}

function otpPolicy() {
  return {
    userConsentRequired: true,
    usesAndroidSmsUserConsent: true,
    noReadSmsPermission: true,
    noOtpStorage: true,
    userStillConfirmsPayment: true
  };
}

async function createPaymentAttempt(account, bill, mode, redirectUrl, batchId = null) {
  const attempts = readPaymentAttempts();
  const attempt = {
    id: `attempt-${account.id}-${Date.now()}`,
    batchId,
    accountId: account.id,
    accountName: account.displayName,
    provider: account.provider,
    amount: Number(bill.amount),
    currencyCode: bill.currencyCode || "AED",
    billMonth: bill.billMonth || currentMonth(),
    mode,
    redirectUrl: redirectUrl || null,
    status: "provider_checkout_ready",
    otpPolicy: otpPolicy(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    verifiedAt: null,
    paymentId: null
  };

  attempts.attempts = [attempt, ...attempts.attempts].slice(0, 250);
  await writePaymentAttempts(attempts);
  await appendPaymentEvent({
    type: "payment_attempt_created",
    attemptId: attempt.id,
    accountId: account.id,
    accountName: account.displayName,
    provider: account.provider,
    amount: attempt.amount,
    currencyCode: attempt.currencyCode,
    mode,
    createdAt: attempt.createdAt
  });
  return attempt;
}

function publicPaymentAttempt(attempt) {
  return {
    id: attempt.id,
    batchId: attempt.batchId,
    accountId: attempt.accountId,
    accountName: attempt.accountName,
    provider: attempt.provider,
    amount: attempt.amount,
    currencyCode: attempt.currencyCode,
    billMonth: attempt.billMonth,
    mode: attempt.mode,
    status: attempt.status,
    otpPolicy: attempt.otpPolicy,
    createdAt: attempt.createdAt,
    updatedAt: attempt.updatedAt,
    verifiedAt: attempt.verifiedAt,
    paymentId: attempt.paymentId
  };
}

async function updatePaymentAttempt(attemptId, changes) {
  const attempts = readPaymentAttempts();
  let updated = null;
  attempts.attempts = attempts.attempts.map((attempt) => {
    if (attempt.id !== attemptId) return attempt;
    updated = {
      ...attempt,
      ...changes,
      updatedAt: new Date().toISOString()
    };
    return updated;
  });

  if (!updated) {
    const err = new Error("Payment attempt was not found.");
    err.statusCode = 404;
    err.code = "payment_attempt_not_found";
    throw err;
  }

  await writePaymentAttempts(attempts);
  return updated;
}

function findPaymentAttempt(attemptId) {
  const attempts = readPaymentAttempts();
  return attempts.attempts.find((attempt) => attempt.id === attemptId) || null;
}

function sanitizePaymentAttemptEvent(attemptId, body) {
  const allowedTypes = new Set([
    "provider_checkout_opened",
    "otp_consent_requested",
    "otp_consent_approved",
    "otp_consent_cancelled",
    "otp_code_autofilled",
    "payment_confirmed_by_user",
    "payment_verified",
    "payment_failed"
  ]);
  const type = allowedTypes.has(body.type) ? body.type : "payment_attempt_event";
  const rawCode = body.code || body.otp || body.oneTimePassword || body.one_time_password;

  return {
    type,
    attemptId,
    accountId: body.accountId || undefined,
    source: body.source || "gopal_web",
    note: body.note || undefined,
    digitCount: rawCode ? String(rawCode).replace(/\D/g, "").length : body.digitCount || undefined,
    rawOtpStored: false,
    createdAt: new Date().toISOString()
  };
}

async function recordPaymentAttemptEvent(attemptId, body) {
  const attempt = findPaymentAttempt(attemptId);
  if (!attempt) {
    const err = new Error("Payment attempt was not found.");
    err.statusCode = 404;
    err.code = "payment_attempt_not_found";
    throw err;
  }

  const event = sanitizePaymentAttemptEvent(attemptId, body);
  await appendPaymentEvent(event);

  const statusByEvent = {
    provider_checkout_opened: "provider_checkout_opened",
    otp_consent_requested: "otp_consent_waiting",
    otp_consent_approved: "otp_consent_approved",
    otp_consent_cancelled: "otp_consent_cancelled",
    otp_code_autofilled: "otp_autofilled_waiting_for_confirm",
    payment_confirmed_by_user: "payment_confirmation_submitted",
    payment_verified: "payment_verified",
    payment_failed: "payment_failed"
  };

  const updated = statusByEvent[event.type]
    ? await updatePaymentAttempt(attemptId, { status: statusByEvent[event.type] })
    : attempt;

  return {
    ok: true,
    event,
    paymentAttempt: publicPaymentAttempt(updated)
  };
}

function successfulVerificationStatus(payload) {
  const status = String(
    payload.status || payload.paymentStatus || payload.state || payload.result || ""
  ).toLowerCase();
  return ["paid", "success", "successful", "completed", "captured", "settled"].includes(status);
}

async function verifyPaymentAttempt(attemptId, payload) {
  const attempt = findPaymentAttempt(attemptId);
  if (!attempt) {
    const err = new Error("Payment attempt was not found.");
    err.statusCode = 404;
    err.code = "payment_attempt_not_found";
    throw err;
  }

  const account = BILL_ACCOUNTS.accounts.find((item) => item.id === attempt.accountId);
  if (!account) {
    const err = new Error("Payment attempt account or bill was not found.");
    err.statusCode = 409;
    err.code = "payment_attempt_context_missing";
    throw err;
  }

  const bill = effectiveBillForAccount(readBillCache(), account);
  if (!bill) {
    const err = new Error("Payment attempt account or bill was not found.");
    err.statusCode = 409;
    err.code = "payment_attempt_context_missing";
    throw err;
  }

  if (attempt.paymentId) {
    const existingPayment = readPaymentHistory().payments.find(
      (payment) => payment.id === attempt.paymentId
    );
    return {
      ok: true,
      message: "Payment attempt was already verified.",
      paymentAttempt: publicPaymentAttempt(attempt),
      payment: existingPayment || null
    };
  }

  if (!successfulVerificationStatus(payload)) {
    const updated = await updatePaymentAttempt(attemptId, {
      status: "payment_failed",
      verifiedAt: new Date().toISOString()
    });
    await appendPaymentEvent({
      type: "payment_failed",
      attemptId,
      accountId: attempt.accountId,
      provider: attempt.provider,
      verificationStatus: payload.status || payload.paymentStatus || payload.state || null,
      rawOtpStored: false,
      createdAt: new Date().toISOString()
    });
    return {
      ok: false,
      code: "payment_not_verified",
      message: "Provider verification did not confirm a paid status.",
      paymentAttempt: publicPaymentAttempt(updated)
    };
  }

  const payment = await recordPayment(
    account,
    bill,
    {
      ...payload,
      status: "paid",
      paymentAttemptId: attemptId
    },
    {
      batchId: attempt.batchId,
      paymentAttemptId: attemptId
    }
  );
  const updated = await updatePaymentAttempt(attemptId, {
    status: "payment_verified",
    verifiedAt: new Date().toISOString(),
    paymentId: payment.id
  });
  await appendPaymentEvent({
    type: "payment_verified",
    attemptId,
    accountId: attempt.accountId,
    paymentId: payment.id,
    provider: attempt.provider,
    rawOtpStored: false,
    createdAt: new Date().toISOString()
  });

  return {
    ok: true,
    message: "Payment verified and receipt workflow started.",
    paymentAttempt: publicPaymentAttempt(updated),
    payment
  };
}

function normalizePaymentStatus(result) {
  const rawStatus = String(
    result.status || result.paymentStatus || result.state || result.result || "submitted"
  ).toLowerCase();

  if (["paid", "success", "successful", "completed", "captured", "settled"].includes(rawStatus)) {
    return "paid";
  }
  if (["failed", "declined", "rejected", "cancelled", "canceled"].includes(rawStatus)) {
    return "failed";
  }
  return "submitted";
}

function receiptFromResult(result) {
  const receipt = result.receipt || {};
  return {
    receiptUrl: result.receiptUrl || result.receipt_url || receipt.url || null,
    receiptNumber: result.receiptNumber || result.receipt_number || receipt.number || null
  };
}

async function recordPayment(account, bill, connectorResult, options = {}) {
  const batchId = typeof options === "string" ? options : options.batchId || null;
  const paymentAttemptId = typeof options === "object" ? options.paymentAttemptId || null : null;
  const status = normalizePaymentStatus(connectorResult);
  const receipt = receiptFromResult(connectorResult);
  const payment = {
    id: `pay-${account.id}-${Date.now()}`,
    batchId,
    paymentAttemptId,
    accountId: account.id,
    accountName: account.displayName,
    provider: account.provider,
    amount: Number(bill.amount),
    currencyCode: bill.currencyCode || "AED",
    status,
    paidAt: new Date().toISOString(),
    billMonth: bill.billMonth || currentMonth(),
    description: bill.description,
    receiptStatus: receipt.receiptUrl ? "provider_receipt_ready" : "provider_receipt_needed",
    receiptUrl: receipt.receiptUrl,
    receiptNumber: receipt.receiptNumber,
    whatsappSentAt: null
  };

  const history = readPaymentHistory();
  history.payments = [payment, ...history.payments];
  await writePaymentHistory(history);
  await updateBillAfterPayment(payment);

  const whatsapp = await sendWhatsAppReceipt(payment);
  if (whatsapp.ok) {
    payment.whatsappSentAt = new Date().toISOString();
    history.payments = history.payments.map((item) => (item.id === payment.id ? payment : item));
    await writePaymentHistory(history);
  }

  return {
    ...payment,
    whatsapp
  };
}

async function updateBillAfterPayment(payment) {
  const cache = readBillCache();
  cache.bills = cache.bills.map((bill) => {
    if (bill.accountId !== payment.accountId) return bill;
    return {
      ...bill,
      status: payment.status === "paid" ? "paid" : "payment_submitted",
      receiptStatus: payment.receiptStatus,
      paymentId: payment.id,
      paidAt: payment.paidAt,
      needsLiveRefresh: payment.status !== "paid"
    };
  });
  cache.updatedAt = new Date().toISOString();
  await writeBillCache(cache);
}

async function sendWhatsAppReceipt(payment) {
  const phone = process.env[BILL_ACCOUNTS.owner.whatsappEnv];
  const token = process.env[BILL_ACCOUNTS.whatsapp.cloudTokenEnv];
  const phoneNumberId = process.env[BILL_ACCOUNTS.whatsapp.phoneNumberIdEnv];

  if (!hasValue(phone) || !hasValue(token) || !hasValue(phoneNumberId)) {
    return {
      ok: false,
      code: "whatsapp_not_configured",
      message: "WhatsApp Cloud API is not configured."
    };
  }

  const response = await fetch(`https://graph.facebook.com/v20.0/${phoneNumberId}/messages`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      to: phone.replace(/[^\d]/g, ""),
      type: "text",
      text: {
        preview_url: Boolean(payment.receiptUrl),
        body: receiptMessage(payment)
      }
    })
  });

  const data = await safeJson(response);
  if (!response.ok) {
    return {
      ok: false,
      code: "whatsapp_send_failed",
      providerStatus: response.status,
      message: "WhatsApp receipt delivery failed.",
      details: data
    };
  }

  return {
    ok: true,
    message: "Receipt sent to configured WhatsApp number.",
    providerMessageId: data.messages?.[0]?.id || null
  };
}

function receiptMessage(payment) {
  const lines = [
    "GOPAL payment receipt",
    `Account: ${payment.accountName}`,
    `Provider: ${payment.provider}`,
    `Amount: ${payment.currencyCode} ${payment.amount.toFixed(2)}`,
    `Status: ${payment.status}`,
    `Bill month: ${payment.billMonth}`,
    `Payment ID: ${payment.id}`
  ];

  if (payment.receiptNumber) lines.push(`Provider receipt: ${payment.receiptNumber}`);
  if (payment.receiptUrl) lines.push(`Receipt link: ${payment.receiptUrl}`);

  return lines.join("\n");
}

async function resendReceipt(paymentId) {
  const history = readPaymentHistory();
  const payment = history.payments.find((item) => item.id === paymentId);
  if (!payment) {
    const err = new Error("Payment history record was not found.");
    err.statusCode = 404;
    err.code = "payment_not_found";
    throw err;
  }

  const whatsapp = await sendWhatsAppReceipt(payment);
  if (whatsapp.ok) {
    payment.whatsappSentAt = new Date().toISOString();
    history.payments = history.payments.map((item) => (item.id === payment.id ? payment : item));
    await writePaymentHistory(history);
  }

  return {
    payment,
    whatsapp
  };
}

async function payTotalBills() {
  const cache = readBillCache();
  const payableAccounts = BILL_ACCOUNTS.accounts.filter((account) =>
    isPayableBill(effectiveBillForAccount(cache, account))
  );

  if (!payableAccounts.length) {
    const err = new Error("No payable bills are currently loaded.");
    err.statusCode = 409;
    err.code = "no_payable_bills";
    throw err;
  }

  const batchId = `batch-${Date.now()}`;
  const results = [];

  for (const account of payableAccounts) {
    try {
      const result = await createOneTapPaymentInstruction(account.id, {
        batchId,
        allowRedirect: false
      });
      results.push({
        accountId: account.id,
        accountName: account.displayName,
        ok: true,
        result
      });
    } catch (error) {
      results.push({
        accountId: account.id,
        accountName: account.displayName,
        ok: false,
        code: error.code || "payment_failed",
        message: error.message
      });
    }
  }

  const failed = results.filter((result) => !result.ok);
  return {
    ok: failed.length === 0,
    batchId,
    paidCount: results.length - failed.length,
    failedCount: failed.length,
    results
  };
}

function appBaseUrl(req) {
  if (process.env.APP_BASE_URL && !process.env.APP_BASE_URL.includes("your-domain.com")) {
    return process.env.APP_BASE_URL.replace(/\/$/, "");
  }

  const proto = req.headers["x-forwarded-proto"] || "http";
  const host = req.headers["x-forwarded-host"] || req.headers.host;
  return `${proto}://${host}`;
}

function sendJson(res, statusCode, payload) {
  const body = JSON.stringify(payload, null, 2);
  sendHeaders(res, statusCode, "application/json; charset=utf-8");
  res.end(body);
}

function sendHeaders(res, statusCode, contentType) {
  res.writeHead(statusCode, {
    "Content-Type": contentType,
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer",
    "X-Frame-Options": "DENY",
    "Permissions-Policy": "payment=(), camera=(), microphone=(), geolocation=()",
    "Cache-Control": contentType.startsWith("audio/")
      ? "public, max-age=31536000, immutable"
      : "no-store"
  });
}

async function readRequestJson(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  if (!chunks.length) return {};

  const body = Buffer.concat(chunks).toString("utf8");
  return JSON.parse(body);
}

async function obtainAccessToken() {
  const cfg = gatewayConfig();
  const response = await fetch(`${cfg.baseUrl}/identity/auth/access-token`, {
    method: "POST",
    headers: {
      "Content-Type": "application/vnd.ni-identity.v1+json",
      Authorization: `Basic ${cfg.apiKey}`
    },
    body: JSON.stringify({
      grant_type: "client_credentials",
      realm: cfg.realm
    })
  });

  const data = await safeJson(response);
  if (!response.ok || !data.access_token) {
    throw gatewayError("N-Genius authentication failed.", response.status, data);
  }

  return data.access_token;
}

async function createNgeniusOrder(req, customer) {
  const cfg = gatewayConfig();
  if (!publicGatewayStatus().enabled) {
    const err = new Error("N-Genius gateway is not configured.");
    err.statusCode = 424;
    err.code = "gateway_not_configured";
    throw err;
  }

  const token = await obtainAccessToken();
  const base = appBaseUrl(req);
  const details = PAYMENT_DETAILS;

  const orderRequest = {
    action: "PURCHASE",
    amount: {
      currencyCode: details.amount.currencyCode,
      value: details.amount.minorUnits
    },
    emailAddress: customer.email || "",
    merchantAttributes: {
      redirectUrl: `${base}/payment/return`,
      cancelUrl: `${base}/payment/cancel`,
      cancelText: "Cancel payment"
    },
    categorizedOrderSummary: true,
    orderSummary: {
      total: {
        currencyCode: details.amount.currencyCode,
        value: details.amount.minorUnits
      },
      items: details.lineItems.map((item) => ({
        category: item.category,
        description: item.description,
        quantity: 1,
        totalPrice: {
          currencyCode: details.amount.currencyCode,
          value: item.minorUnits
        }
      }))
    }
  };

  const response = await fetch(`${cfg.baseUrl}/transactions/outlets/${cfg.outletRef}/orders`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/vnd.ni-payment.v2+json",
      Accept: "application/vnd.ni-payment.v2+json"
    },
    body: JSON.stringify(orderRequest)
  });

  const order = await safeJson(response);
  if (!response.ok) {
    throw gatewayError("N-Genius order creation failed.", response.status, order);
  }

  const paymentUrl = order?._links?.payment?.href;
  if (!paymentUrl) {
    throw gatewayError("N-Genius did not return a hosted payment page URL.", response.status, order);
  }

  await appendPaymentEvent({
    type: "order_created",
    reference: order.reference,
    paymentReference: details.reference,
    amount: details.amount,
    createdAt: new Date().toISOString()
  });

  return {
    paymentUrl,
    orderReference: order.reference,
    paymentReference: details.reference,
    provider: "ngenius",
    mode: cfg.env
  };
}

async function appendPaymentEvent(event) {
  await fsp.mkdir(DATA_DIR, { recursive: true });
  await fsp.appendFile(PAYMENT_EVENTS_PATH, `${JSON.stringify(event)}\n`, "utf8");
}

function gatewayError(message, status, data) {
  const err = new Error(message);
  err.statusCode = status >= 400 && status < 600 ? status : 502;
  err.code = "gateway_error";
  err.gatewayStatus = status;
  err.gatewayResponse = data;
  return err;
}

async function safeJson(response) {
  const text = await response.text();
  if (!text) return {};

  try {
    return JSON.parse(text);
  } catch {
    return { raw: text };
  }
}

async function handleApi(req, res, url) {
  if (req.method === "GET" && url.pathname === "/api/health") {
    return sendJson(res, 200, {
      ok: true,
      system: "GOPAL Private Bill Hub",
      gateway: publicGatewayStatus(),
      paymentProfile: publicPaymentProfile()
    });
  }

  if (req.method === "GET" && url.pathname === "/api/bill-hub") {
    return sendJson(res, 200, billHubPayload());
  }

  if (req.method === "GET" && url.pathname === "/api/setup-status") {
    return sendJson(res, 200, billHubPayload().productionSetup);
  }

  if (req.method === "POST" && url.pathname === "/api/bills/refresh") {
    try {
      const hub = await refreshBills();
      return sendJson(res, 200, hub);
    } catch (error) {
      return sendJson(res, error.statusCode || 500, {
        ok: false,
        code: error.code || "refresh_failed",
        message: error.message
      });
    }
  }

  if (req.method === "POST" && url.pathname === "/api/bills/pay-total") {
    try {
      const body = await readRequestJson(req);
      if (body.confirm !== true) {
        return sendJson(res, 400, {
          ok: false,
          code: "confirmation_required",
          message: "Total payment requires explicit button confirmation."
        });
      }

      const result = await payTotalBills();
      return sendJson(res, result.ok ? 201 : 207, result);
    } catch (error) {
      return sendJson(res, error.statusCode || 500, {
        ok: false,
        code: error.code || "total_payment_failed",
        message: error.message
      });
    }
  }

  const payMatch = url.pathname.match(/^\/api\/bills\/([^/]+)\/pay$/);
  if (req.method === "POST" && payMatch) {
    try {
      const body = await readRequestJson(req);
      if (body.confirm !== true) {
        return sendJson(res, 400, {
          ok: false,
          code: "confirmation_required",
          message: "One-tap payment requires explicit button confirmation."
        });
      }

      const result = await createOneTapPaymentInstruction(payMatch[1]);
      return sendJson(res, 201, result);
    } catch (error) {
      return sendJson(res, error.statusCode || 500, {
        ok: false,
        code: error.code || "payment_failed",
        message: error.message
      });
    }
  }

  if (req.method === "GET" && url.pathname === "/api/payment-history") {
    return sendJson(res, 200, readPaymentHistory());
  }

  const attemptMatch = url.pathname.match(/^\/api\/payment-attempts\/([^/]+)$/);
  if (req.method === "GET" && attemptMatch) {
    const attempt = findPaymentAttempt(attemptMatch[1]);
    if (!attempt) {
      return sendJson(res, 404, {
        ok: false,
        code: "payment_attempt_not_found",
        message: "Payment attempt was not found."
      });
    }
    return sendJson(res, 200, publicPaymentAttempt(attempt));
  }

  const attemptEventMatch = url.pathname.match(/^\/api\/payment-attempts\/([^/]+)\/events$/);
  if (req.method === "POST" && attemptEventMatch) {
    try {
      const body = await readRequestJson(req);
      const result = await recordPaymentAttemptEvent(attemptEventMatch[1], body);
      return sendJson(res, 201, result);
    } catch (error) {
      return sendJson(res, error.statusCode || 500, {
        ok: false,
        code: error.code || "payment_attempt_event_failed",
        message: error.message
      });
    }
  }

  const otpConsentStartedMatch = url.pathname.match(
    /^\/api\/payments\/([^/]+)\/otp-consent-started$/
  );
  if (req.method === "POST" && otpConsentStartedMatch) {
    try {
      const body = await readRequestJson(req);
      const result = await recordPaymentAttemptEvent(otpConsentStartedMatch[1], {
        ...body,
        type: "otp_consent_requested",
        source: "android_user_consent"
      });
      return sendJson(res, 201, result);
    } catch (error) {
      return sendJson(res, error.statusCode || 500, {
        ok: false,
        code: error.code || "otp_consent_event_failed",
        message: error.message
      });
    }
  }

  const otpAutofilledMatch = url.pathname.match(/^\/api\/payments\/([^/]+)\/otp-autofilled$/);
  if (req.method === "POST" && otpAutofilledMatch) {
    try {
      const body = await readRequestJson(req);
      const result = await recordPaymentAttemptEvent(otpAutofilledMatch[1], {
        ...body,
        type: "otp_code_autofilled",
        source: "android_user_consent"
      });
      return sendJson(res, 201, result);
    } catch (error) {
      return sendJson(res, error.statusCode || 500, {
        ok: false,
        code: error.code || "otp_autofill_event_failed",
        message: error.message
      });
    }
  }

  const attemptVerifyMatch = url.pathname.match(/^\/api\/payment-attempts\/([^/]+)\/verify$/);
  if (req.method === "POST" && attemptVerifyMatch) {
    const expectedToken = process.env.GOPAL_WEBHOOK_TOKEN;
    if (expectedToken && req.headers["x-gopal-webhook-token"] !== expectedToken) {
      return sendJson(res, 401, { ok: false, code: "unauthorized_webhook" });
    }

    try {
      const body = await readRequestJson(req);
      const result = await verifyPaymentAttempt(attemptVerifyMatch[1], body);
      return sendJson(res, result.ok ? 200 : 409, result);
    } catch (error) {
      return sendJson(res, error.statusCode || 500, {
        ok: false,
        code: error.code || "payment_verification_failed",
        message: error.message
      });
    }
  }

  const receiptMatch = url.pathname.match(/^\/api\/receipts\/([^/]+)\/send-whatsapp$/);
  if (req.method === "POST" && receiptMatch) {
    try {
      const result = await resendReceipt(receiptMatch[1]);
      return sendJson(res, result.whatsapp.ok ? 200 : 424, result);
    } catch (error) {
      return sendJson(res, error.statusCode || 500, {
        ok: false,
        code: error.code || "receipt_send_failed",
        message: error.message
      });
    }
  }

  if (req.method === "GET" && url.pathname === "/api/payment-details") {
    return sendJson(res, 200, {
      ...PAYMENT_DETAILS,
      gateway: publicGatewayStatus(),
      voices: VOICE_FILES
    });
  }

  if (req.method === "GET" && url.pathname === "/api/audio-map") {
    return sendJson(res, 200, VOICE_FILES);
  }

  if (req.method === "POST" && url.pathname === "/api/payments/ngenius/create-order") {
    try {
      const body = await readRequestJson(req);
      const result = await createNgeniusOrder(req, body.customer || {});
      return sendJson(res, 201, result);
    } catch (error) {
      return sendJson(res, error.statusCode || 500, {
        ok: false,
        code: error.code || "payment_error",
        message: error.message
      });
    }
  }

  if (req.method === "POST" && url.pathname === "/api/payments/ngenius/webhook") {
    const expectedToken = process.env.GOPAL_WEBHOOK_TOKEN;
    if (expectedToken && req.headers["x-gopal-webhook-token"] !== expectedToken) {
      return sendJson(res, 401, { ok: false, code: "unauthorized_webhook" });
    }

    try {
      const payload = await readRequestJson(req);
      await appendPaymentEvent({
        type: "gateway_webhook",
        payload,
        receivedAt: new Date().toISOString()
      });
      return sendJson(res, 200, { ok: true });
    } catch {
      return sendJson(res, 400, { ok: false, code: "invalid_webhook_payload" });
    }
  }

  return sendJson(res, 404, { ok: false, code: "not_found" });
}

async function serveStatic(req, res, url) {
  const indexRoutes = new Set(["/", "/payment/return", "/payment/cancel"]);
  const requestedPath = indexRoutes.has(url.pathname) ? "/index.html" : url.pathname;
  const decodedPath = decodeURIComponent(requestedPath);
  const normalizedPath = path.normalize(decodedPath).replace(/^(\.\.[/\\])+/, "");
  const filePath = path.join(PUBLIC_DIR, normalizedPath);

  if (!filePath.startsWith(PUBLIC_DIR)) {
    sendHeaders(res, 403, "text/plain; charset=utf-8");
    return res.end("Forbidden");
  }

  try {
    const file = await fsp.readFile(filePath);
    const ext = path.extname(filePath);
    sendHeaders(res, 200, MIME_TYPES[ext] || "application/octet-stream");
    res.end(file);
  } catch {
    sendHeaders(res, 404, "text/plain; charset=utf-8");
    res.end("Not found");
  }
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host}`);
    if (url.pathname.startsWith("/api/")) {
      return await handleApi(req, res, url);
    }
    return await serveStatic(req, res, url);
  } catch (error) {
    return sendJson(res, 500, {
      ok: false,
      code: "server_error",
      message: "Unexpected server error."
    });
  }
});

const port = Number(process.env.PORT || 8080);
server.listen(port, () => {
  console.log(`GOPAL Private Bill Hub running on http://localhost:${port}`);
});
